package com.yourname.sovereignnations.visual;

import com.yourname.sovereignnations.SovereignNations;
import org.bukkit.Chunk;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import org.bukkit.World;

/**
 * Small utility to show chunk border particles to a single player for a short duration.
 */
public class ClaimVisuals {

    public static void showChunkBorderToPlayer(Player player, Chunk chunk, int seconds) {
        World world = chunk.getWorld();
        int cx = chunk.getX() << 4; // block x
        int cz = chunk.getZ() << 4; // block z

        Runnable task = new Runnable() {
            int ticksLeft = seconds * 20;

            @Override
            public void run() {
                if (ticksLeft <= 0) return;
                // Draw particles along the full chunk perimeter at two heights for visibility
                int playerY = player.getLocation().getBlockY();
                int h1 = Math.max(60, Math.min(playerY, world.getMaxHeight() - 5));
                int h2 = Math.min(world.getMaxHeight() - 2, h1 + 3);

                // edges along X (z fixed)
                for (int x = cx; x <= cx + 16; x += 2) {
                    spawnParticleAt(player, world, x + 0.5, h1, cz + 0.5);
                    spawnParticleAt(player, world, x + 0.5, h2, cz + 0.5);
                    spawnParticleAt(player, world, x + 0.5, h1, cz + 16 + 0.5);
                    spawnParticleAt(player, world, x + 0.5, h2, cz + 16 + 0.5);
                }

                // edges along Z (x fixed)
                for (int z = cz; z <= cz + 16; z += 2) {
                    spawnParticleAt(player, world, cx + 0.5, h1, z + 0.5);
                    spawnParticleAt(player, world, cx + 16 + 0.5, h1, z + 0.5);
                    spawnParticleAt(player, world, cx + 0.5, h2, z + 0.5);
                    spawnParticleAt(player, world, cx + 16 + 0.5, h2, z + 0.5);
                }

                ticksLeft -= 5; // we schedule every 5 ticks
            }

            private void spawnParticleAt(Player player, World world, double x, double y, double z) {
                Location loc = new Location(world, x, y, z);
                player.spawnParticle(Particle.HAPPY_VILLAGER, loc, 1, 0, 0, 0, 0.0);
            }
        };

        int taskId = SovereignNations.get().getServer().getScheduler().scheduleSyncRepeatingTask(SovereignNations.get(), task, 0L, 5L);
        // cancel after duration
        SovereignNations.get().getServer().getScheduler().runTaskLater(SovereignNations.get(), () -> {
            SovereignNations.get().getServer().getScheduler().cancelTask(taskId);
        }, seconds * 20L + 2L);
    }
}