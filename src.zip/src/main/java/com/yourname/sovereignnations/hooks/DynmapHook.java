package com.yourname.sovereignnations.hooks;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.claims.Claim;
import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.lang.reflect.Method;
import java.util.logging.Level;

/**
 * Optional Dynmap integration using reflection. Safe when dynmap is absent.
 */
public class DynmapHook {
    private static Object dynmap; // dynmap plugin object
    private static Object markerAPI;

    public static boolean init(SovereignNations plugin) {
        try {
            org.bukkit.plugin.Plugin pl = Bukkit.getPluginManager().getPlugin("dynmap");
            if (pl == null) return false;
            dynmap = pl;
            // Try to get the MarkerAPI via reflection (dynmap API)
            Class<?> c = Class.forName("org.dynmap.DynmapPlugin");
            Method m = c.getMethod("getMarkerAPI");
            markerAPI = m.invoke(dynmap);
            plugin.getLogger().info("Dynmap hooked successfully (optional). Markers will be shown if configured.");
            return true;
        } catch (Throwable t) {
            // Dynmap not present or API changed
            plugin.getLogger().info("Dynmap not available or hook failed: " + t.getMessage());
            return false;
        }
    }

    public static void shutdown() {
        // nothing to clean up for now
    }

    public static void addClaimMarker(Claim claim) {
        if (markerAPI == null) return;
        try {
            // Attempt to create a marker via MarkerAPI if available
            Class<?> apiClass = markerAPI.getClass();
            Method createMarker = apiClass.getMethod("createMarker", String.class, String.class, double.class, double.class, double.class, String.class);
            // marker id, label, x,y,z, world
            createMarker.invoke(markerAPI, "sn-claim-" + claim.getNationId().toString() + "-" + claim.getKey(), claim.toString(), claim.getChunkX()*16 + 8.0, 64.0, claim.getChunkZ()*16 + 8.0, claim.getWorldName());
        } catch (Throwable t) {
            Bukkit.getLogger().log(Level.FINE, "Dynmap marker creation failed: " + t.getMessage());
        }
    }

    public static void removeClaimMarker(Claim claim) {
        if (markerAPI == null) return;
        try {
            Class<?> apiClass = markerAPI.getClass();
            Method deleteMarker = apiClass.getMethod("deleteMarker", String.class);
            deleteMarker.invoke(markerAPI, "sn-claim-" + claim.getNationId().toString() + "-" + claim.getKey());
        } catch (Throwable t) {
            Bukkit.getLogger().log(Level.FINE, "Dynmap marker remove failed: " + t.getMessage());
        }
    }

    public static void refreshAll() {
        // No-op for now — marker API may handle live updates
    }
}
