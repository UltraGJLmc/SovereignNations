package com.yourname.sovereignnations.hooks;

import com.yourname.sovereignnations.SovereignNations;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * Handles integration with Vault economy.
 */
public class VaultHook {

    private static Economy economy;

    // Backwards-compatible initializer name expected by main plugin
    public static boolean init(com.yourname.sovereignnations.SovereignNations plugin) {
        return setupVault(plugin);
    }

    /**
     * Setup Vault economy hook.
     * @param plugin The main plugin instance
     * @return true if Vault is present and economy provider found
     */
    public static boolean setupVault(SovereignNations plugin) {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("Vault not found! Economy features may be limited.");
            return false;
        }

        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            plugin.getLogger().warning("No Vault economy provider found! Economy features may be limited.");
            return false;
        }

        economy = rsp.getProvider();
        plugin.getLogger().info("Vault hooked successfully: " + economy.getName());
        return true;
    }

    /**
     * Get player's balance.
     */
    public static double getBalance(Player player) {
        if (economy == null) return 0;
        return economy.getBalance(player);
    }

    /**
     * Check if player has enough money.
     */
    public static boolean has(Player player, double amount) {
        if (economy == null) return false;
        return economy.has(player, amount);
    }

    /**
     * Withdraw money from player.
     */
    public static boolean withdraw(Player player, double amount) {
        if (economy == null) return false;
        return economy.withdrawPlayer(player, amount).transactionSuccess();
    }

    /**
     * Deposit money to player.
     */
    public static boolean deposit(Player player, double amount) {
        if (economy == null) return false;
        return economy.depositPlayer(player, amount).transactionSuccess();
    }

    /**
     * Format money string.
     */
    public static String format(double amount) {
        if (economy == null) return amount + " $";
        return economy.format(amount);
    }

    /**
     * Check if Vault is hooked.
     */
    public static boolean isHooked() {
        return economy != null;
    }
}
