package com.yourname.sovereignnations.hooks;

import com.earth2me.essentials.Essentials;
import com.earth2me.essentials.User;
import com.yourname.sovereignnations.SovereignNations;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * Handles integration with EssentialsX for economy and player utilities.
 */
public class EssentialsHook {
    private static Essentials essentials;

    public static boolean setupEssentials(SovereignNations plugin) {
        Plugin pl = Bukkit.getPluginManager().getPlugin("Essentials");
        if (pl == null || !(pl instanceof Essentials)) {
            plugin.getLogger().warning("Essentials not found! Some features may be disabled.");
            return false;
        }
        essentials = (Essentials) pl;
        plugin.getLogger().info("Essentials hooked successfully.");
        return true;
    }

    public static double getBalance(Player player) {
        if (essentials == null) return 0;
        try {
            User user = essentials.getUser(player);
            return user.getMoney().doubleValue();
        } catch (Exception e) {
            return 0;
        }
    }

    public static boolean has(Player player, double amount) {
        return getBalance(player) >= amount;
    }

    public static boolean withdraw(Player player, double amount) {
        if (essentials == null) return false;
        try {
            User user = essentials.getUser(player);
            user.takeMoney(java.math.BigDecimal.valueOf(amount));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean deposit(Player player, double amount) {
        if (essentials == null) return false;
        try {
            User user = essentials.getUser(player);
            user.giveMoney(java.math.BigDecimal.valueOf(amount));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String format(double amount) {
        if (essentials == null) return amount + " $";
        try {
            return String.format("%.2f", amount);
        } catch (Exception e) {
            return String.valueOf(amount);
        }
    }
}
