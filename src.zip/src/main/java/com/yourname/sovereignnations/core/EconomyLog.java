package com.yourname.sovereignnations.core;

public class EconomyLog {
    
}
