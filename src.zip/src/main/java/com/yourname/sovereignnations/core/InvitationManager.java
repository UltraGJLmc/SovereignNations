package com.yourname.sovereignnations.core;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks pending invites: invitedPlayerUUID -> invitingNationId
 */
public class InvitationManager {
    private static final Map<UUID, UUID> invites = new ConcurrentHashMap<>();

    public static void invite(UUID playerToInvite, UUID nationId) {
        invites.put(playerToInvite, nationId);
    }

    public static UUID getInvite(UUID player) {
        return invites.get(player);
    }

    public static void accept(UUID player) {
        invites.remove(player);
    }

    public static void cancel(UUID player) {
        invites.remove(player);
    }

    public static boolean hasInvite(UUID player) {
        return invites.containsKey(player);
    }
}