package com.yourname.sovereignnations.core;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.claims.Claim;
import com.yourname.sovereignnations.claims.ClaimManager;
import com.yourname.sovereignnations.hooks.DynmapHook;
import com.yourname.sovereignnations.wars.War;
import com.yourname.sovereignnations.wars.WarManager;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Handles nation upkeep: deducts balance for claims, sends warnings, tracks unpaid days.
 */
public final class UpkeepManager {

    private static SovereignNations plugin;
    private static long checkIntervalTicks = 24 * 60 * 60 * 20L; // 24 hours
    private static double costPerClaim = 10.0;
    private static int deletionAfterUnpaidDays = 3;

    private static BukkitRunnable upkeepTask;

    /* ===================== */
    /* INITIALIZE */
    /* ===================== */

    public static void init(SovereignNations pluginInstance) {
        plugin = pluginInstance;

        costPerClaim = plugin.getConfig().getDouble("upkeep.cost-per-claim", 10.0);
        checkIntervalTicks = plugin.getConfig().getLong("upkeep.check-interval-ticks", checkIntervalTicks);

        deletionAfterUnpaidDays = plugin.getConfig().getInt(
                "settings.upkeep.deletion-after-unpaid-days",
                plugin.getConfig().getInt("upkeep.deletion-after-unpaid-days", deletionAfterUnpaidDays)
        );

        scheduleUpkeepTask();
    }

    /* ===================== */
    /* SCHEDULE TASK */
    /* ===================== */

    private static void scheduleUpkeepTask() {
        if (upkeepTask != null) upkeepTask.cancel();

        upkeepTask = new BukkitRunnable() {
            @Override
            public void run() {
                performUpkeep();
            }
        };

        upkeepTask.runTaskTimer(plugin, 20L, checkIntervalTicks);
    }

    /* ===================== */
    /* PERFORM UPKEEP */
    /* ===================== */

    public static void performUpkeep() {
        Collection<Nation> nations = new ArrayList<>(NationManager.getAllNations());

        for (Nation nation : nations) {
            List<Claim> claims = ClaimManager.getAllClaims(nation);
            int totalClaims = claims.size();

            if (totalClaims <= 0) {
                nation.setUnpaidDays(0);
                continue;
            }

            double totalCost = totalClaims * costPerClaim;

            if (EconomyManager.withdrawNation(nation, totalCost)) {
                nation.setLastUpkeepPaid(System.currentTimeMillis());
                nation.setUnpaidDays(0);
                notifyNation(nation, "§aUpkeep paid: " + EconomyManager.format(totalCost));
            } else {
                int unpaidDays = nation.getUnpaidDays() + 1;
                nation.setUnpaidDays(unpaidDays);

                notifyNation(
                        nation,
                        "§cUpkeep unpaid (" + EconomyManager.format(totalCost) +
                                "). Unpaid days: " + unpaidDays + "/" + deletionAfterUnpaidDays
                );

                if (unpaidDays >= deletionAfterUnpaidDays) {
                    handleUnpaidNation(nation);
                }
            }
        }

        NationManager.saveAll();
        ClaimManager.saveAll();
    }

    /* ===================== */
    /* HANDLE UNPAID */
    /* ===================== */

    private static void handleUnpaidNation(Nation nation) {
        try {
            // Unclaim all claims
            for (Claim claim : ClaimManager.getAllClaims(nation)) {
                ClaimManager.unclaimChunk(claim);
                DynmapHook.removeClaimMarker(claim);
            }

            // End wars safely
            List<War> wars = WarManager.getWars(nation);
            if (wars != null) {
                for (War war : new ArrayList<>(wars)) {
                    WarManager.endWar(war);
                }
            }

            String name = nation.getName();
            Bukkit.broadcastMessage("§cNation §e" + name + " §chas been disbanded due to unpaid upkeep.");

            NationManager.removeNation(nation);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ===================== */
    /* NOTIFY */
    /* ===================== */

    private static void notifyNation(Nation nation, String message) {
        nation.getMembers().keySet().forEach(uuid -> {
            if (Bukkit.getPlayer(uuid) != null) {
                Bukkit.getPlayer(uuid).sendMessage(message);
            }
        });
    }

    /* ===================== */
    /* MANUAL UPKEEP */
    /* ===================== */

    public static void performUpkeep(Nation nation) {
        if (nation == null) return;

        int totalClaims = ClaimManager.getAllClaims(nation).size();
        if (totalClaims <= 0) return;

        double totalCost = totalClaims * costPerClaim;

        if (EconomyManager.withdrawNation(nation, totalCost)) {
            nation.setLastUpkeepPaid(System.currentTimeMillis());
            nation.setUnpaidDays(0);
            notifyNation(nation, "§aManual upkeep paid: " + EconomyManager.format(totalCost));
        } else {
            int unpaidDays = nation.getUnpaidDays() + 1;
            nation.setUnpaidDays(unpaidDays);
            notifyNation(nation, "§cManual upkeep failed. Unpaid days: " + unpaidDays);

            if (unpaidDays >= deletionAfterUnpaidDays) {
                handleUnpaidNation(nation);
            }
        }

        NationManager.saveAll();
        ClaimManager.saveAll();
    }
}
