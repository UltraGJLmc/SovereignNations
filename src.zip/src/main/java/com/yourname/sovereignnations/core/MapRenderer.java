package com.yourname.sovereignnations.core;

import com.yourname.sovereignnations.claims.Claim;
import com.yourname.sovereignnations.claims.ClaimManager;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class MapRenderer {

    /**
     * Render a simple text  map centered on player. Width should be odd (27) and height odd (7).
     */
    private static final java.util.Map<java.util.UUID, Long> lastRender = new java.util.concurrent.ConcurrentHashMap<>();
    private static final long RENDER_COOLDOWN_MS = 3000L; // 3s

    public static boolean canRender(org.bukkit.entity.Player player) {
        Long last = lastRender.get(player.getUniqueId());
        long now = System.currentTimeMillis();
        if (last == null || now - last >= RENDER_COOLDOWN_MS) {
            lastRender.put(player.getUniqueId(), now);
            return true;
        }
        return false;
    }

    public static List<String> renderMap(Player player, int width, int height) {
        List<String> lines = new ArrayList<>();
        if (width % 2 == 0 || height % 2 == 0) {
            lines.add(ChatColor.RED + "Map size must be odd for centering.");
            return lines;
        }

        int halfW = width / 2;
        int halfH = height / 2;
        Chunk center = player.getLocation().getChunk();

        for (int dz = -halfH; dz <= halfH; dz++) {
            StringBuilder sb = new StringBuilder();
            for (int dx = -halfW; dx <= halfW; dx++) {
                int cx = center.getX() + dx;
                int cz = center.getZ() + dz;
                Chunk c = center.getWorld().getChunkAt(cx, cz);
                Claim claim = ClaimManager.getClaim(c);
                if (cx == center.getX() && cz == center.getZ()) {
                    sb.append(ChatColor.YELLOW).append("+");
                    continue;
                }
                if (claim == null) {
                    sb.append(ChatColor.DARK_GRAY).append('-');
                    continue;
                }
                Nation owner = claim.getNation();
                Nation playerNation = PlayerProfileManager.getProfile(player).getNation();
                if (playerNation != null && owner != null && owner.getId().equals(playerNation.getId())) {
                    // your town
                    sb.append(ChatColor.GREEN).append('+');
                } else if (playerNation != null && owner != null) {
                    // check diplomacy
                    if (playerNation.getAllies().contains(owner.getName())) sb.append(ChatColor.DARK_GREEN).append('+');
                    else if (playerNation.getEnemies().contains(owner.getName())) sb.append(ChatColor.RED).append('+');
                    else sb.append(ChatColor.GREEN).append('+');
                } else {
                    sb.append(ChatColor.GREEN).append('+');
                }
            }
            lines.add(sb.toString());
        }

        // Legend
        lines.add(0, ChatColor.GRAY + "Legend: " + ChatColor.YELLOW + "+" + ChatColor.GRAY + "= you, " + ChatColor.GREEN + "+" + ChatColor.GRAY + "= your town, " + ChatColor.DARK_GREEN + "+" + ChatColor.GRAY + "= ally, " + ChatColor.RED + "+" + ChatColor.GRAY + "= enemy, " + ChatColor.DARK_GRAY + "-" + ChatColor.GRAY + "= unclaimed");
        return lines;
    }
}
