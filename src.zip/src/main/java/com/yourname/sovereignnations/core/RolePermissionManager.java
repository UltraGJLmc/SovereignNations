package com.yourname.sovereignnations.core;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.core.PlayerProfile;
import com.yourname.sovereignnations.core.Nation.Role;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Manages role-based permissions for SovereignNations.
 * Permissions can be defined in roles.yml
 */
public class RolePermissionManager {

    private static final Map<Role, List<String>> rolePermissions = new EnumMap<>(Role.class);
    private static SovereignNations plugin;

    /**
     * Initialize the manager and load permissions from YAML
     */
    public static void setup(SovereignNations mainPlugin) {
        plugin = mainPlugin;
        loadPermissions();
    }

    /**
     * Load role permissions from roles.yml
     */
    public static void loadPermissions() {
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();

        // Ensure default resource is available, then load configuration
        plugin.saveResource("roles.yml", false);
        Map<String, Object> data = plugin.getFileConfig("roles.yml").getValues(false);

        for (Role role : Role.values()) {
            List<String> perms = new ArrayList<>();
            if (data.containsKey(role.name())) {
                Object obj = data.get(role.name());
                if (obj instanceof List<?>) {
                    for (Object item : (List<?>) obj) {
                        perms.add(item.toString());
                    }
                }
            }
            rolePermissions.put(role, perms);
        }

        plugin.getLogger().info("Role permissions loaded successfully!");
    }

    /**
     * Add a permission to a role and persist to file
     */
    public static void addPermission(Role role, String permission) {
        List<String> perms = rolePermissions.computeIfAbsent(role, r -> new ArrayList<>());
        if (!perms.contains(permission)) {
            perms.add(permission);
            savePermissions();
        }
    }

    /**
     * Remove a permission from a role and persist
     */
    public static void removePermission(Role role, String permission) {
        List<String> perms = rolePermissions.get(role);
        if (perms != null && perms.remove(permission)) {
            savePermissions();
        }
    }

    /**
     * Persist current role permissions to roles.yml in the plugin data folder
     */
    public static void savePermissions() {
        if (plugin == null) return;
        org.bukkit.configuration.file.FileConfiguration cfg = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(new java.io.File(plugin.getDataFolder(), "roles.yml"));
        for (Role r : Role.values()) {
            List<String> perms = rolePermissions.getOrDefault(r, Collections.emptyList());
            cfg.set(r.name(), perms);
        }
        try {
            cfg.save(new java.io.File(plugin.getDataFolder(), "roles.yml"));
            plugin.getLogger().info("roles.yml saved successfully.");
        } catch (Exception ex) {
            plugin.getLogger().severe("Failed to save roles.yml: " + ex.getMessage());
        }
    }

    /**
     * Reload permissions from disk
     */
    public static void reload() {
        loadPermissions();
    }

    /**
     * Check if a player has permission to perform an action
     * @param profile PlayerProfile of the player
     * @param permission Permission string (e.g., "nation.claim")
     * @return true if allowed
     */
    public static boolean canPerform(PlayerProfile profile, String permission) {
        if (profile == null || profile.getRole() == null) return false;

        Role role = profile.getRole();
        List<String> perms = rolePermissions.get(role);
        return perms != null && perms.contains(permission);
    }

    /**
     * Convenience method for Bukkit Player
     */
    public static boolean canPerform(Player player, String permission) {
        PlayerProfile profile = PlayerProfileManager.getProfile(player);
        return canPerform(profile, permission);
    }

    /**
     * Get all permissions for a role
     */
    public static List<String> getPermissions(Role role) {
        return rolePermissions.getOrDefault(role, Collections.emptyList());
    }
}
