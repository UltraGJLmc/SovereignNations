package com.yourname.sovereignnations.core;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Tier {

    private final String name;
    private final int maxClaims;
    private final int maxMembers;
    private final double taxModifier;
    private final Set<String> allowedPlotTypes;

    public Tier(String name, int maxClaims, int maxMembers, double taxModifier, Set<String> allowedPlotTypes) {
        this.name = name;
        this.maxClaims = maxClaims;
        this.maxMembers = maxMembers;
        this.taxModifier = taxModifier;
        this.allowedPlotTypes = allowedPlotTypes != null ? new HashSet<>(allowedPlotTypes) : new HashSet<>();
    }

    public String getName() { return name; }
    public int getMaxClaims() { return maxClaims; }
    public int getMaxMembers() { return maxMembers; }
    public double getTaxModifier() { return taxModifier; }
    public Set<String> getAllowedPlotTypes() { return Collections.unmodifiableSet(allowedPlotTypes); }
}
