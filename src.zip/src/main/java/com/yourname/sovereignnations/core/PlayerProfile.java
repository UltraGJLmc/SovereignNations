package com.yourname.sovereignnations.core;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

// Bukkit imports (fully compatible with Paper)
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

/**
 * Represents a per-player profile.
 * Cached in memory for fast access.
 */


public class PlayerProfile {

    private final UUID uuid;
    private String playerName;

    // Nation membership (null if none)
    private Nation nation;
    private Nation.Role role = Nation.Role.NONE;

    // Pending invites (nation names)
    private final Set<String> pendingNationInvites = ConcurrentHashMap.newKeySet();

    // GUI settings (example: last opened GUI page)
    private Map<String, Object> guiSettings = new ConcurrentHashMap<>();

    // War participation cache
    private Set<String> currentWars = ConcurrentHashMap.newKeySet();

    // Misc future stats (example: kills, deaths)
    private final Map<String, Integer> stats = new ConcurrentHashMap<>();

    // Chat channel preference
    private com.yourname.sovereignnations.chat.ChatChannel chatChannel = com.yourname.sovereignnations.chat.ChatChannel.PUBLIC;

    /* ===================== */
    /* CONSTRUCTOR */
    /* ===================== */
    public PlayerProfile(UUID uuid, String playerName) {
        this.uuid = uuid;
        this.playerName = playerName;
    }

    /* ===================== */
    /* GETTERS & SETTERS */
    /* ===================== */
    public UUID getUuid() {
        return uuid;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String name) {
        this.playerName = name;
    }

    public Nation getNation() {
        return nation;
    }

    public boolean hasNation() {
        return nation != null;
    }

    public void setNation(Nation nation) {
        this.nation = nation;
        this.role = (nation != null) ? nation.getRole(uuid) : Nation.Role.NONE;
    }

    public Nation.Role getRole() {
        return role;
    }

    public void setRole(Nation.Role role) {
        this.role = role;
    }

    /* ===================== */
    /* INVITES MANAGEMENT */
    /* ===================== */
    public void addInvite(String nationName) {
        pendingNationInvites.add(nationName.toLowerCase());
    }

    public void removeInvite(String nationName) {
        pendingNationInvites.remove(nationName.toLowerCase());
    }

    public boolean hasInvite(String nationName) {
        return pendingNationInvites.contains(nationName.toLowerCase());
    }

    public Set<String> getPendingInvites() {
        return Collections.unmodifiableSet(pendingNationInvites);
    }

    /* ===================== */
    /* GUI SETTINGS */
    /* ===================== */
    public void setGuiSetting(String key, Object value) {
        guiSettings.put(key, value);
    }

    public Object getGuiSetting(String key) {
        return guiSettings.get(key);
    }

    public Map<String, Object> getAllGuiSettings() {
        return Collections.unmodifiableMap(guiSettings);
    }

    /* ===================== */
    /* WAR PARTICIPATION */
    /* ===================== */
    public void joinWar(String warId) {
        currentWars.add(warId);
    }

    public void leaveWar(String warId) {
        currentWars.remove(warId);
    }

    public boolean isInWar(String warId) {
        return currentWars.contains(warId);
    }

    public Set<String> getCurrentWars() {
        return Collections.unmodifiableSet(currentWars);
    }

    /* ===================== */
    /* STATISTICS */
    /* ===================== */
    public void setStat(String key, int value) {
        stats.put(key, value);
    }

    public int getStat(String key) {
        return stats.getOrDefault(key, 0);
    }

    public void incrementStat(String key, int amount) {
        stats.put(key, getStat(key) + amount);
    }

    public Map<String, Integer> getAllStats() {
        return Collections.unmodifiableMap(stats);
    }

    /* ===================== */
    /* CHAT PREFS */

    public com.yourname.sovereignnations.chat.ChatChannel getChatChannel() {
        return chatChannel;
    }

    public void setChatChannel(com.yourname.sovereignnations.chat.ChatChannel chatChannel) {
        this.chatChannel = chatChannel;
    }

    /* ===================== */
    /* UTILITIES */
    /* ===================== */
    public OfflinePlayer getOfflinePlayer() {
        return Bukkit.getOfflinePlayer(uuid);
    }

    public Player getOnlinePlayer() {
        return Bukkit.getPlayer(uuid);
    }
}
