package com.yourname.sovereignnations.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;

import java.util.*;

public class Nation {

    /* ===================== */
    /* ROLE ENUM (REQUIRED) */
    /* ===================== */

    public enum Role {
        LEADER,
        OFFICER,
        BUILDER,
        POLICE,
        SHERIFF,
        RECRUITER,
        HELPER,
        PLANNER,
        MEMBER,
        NONE
    }

    private final UUID id;
    private String name;

    private UUID owner;
    private UUID allianceId;

    private Location home;
    private Location spawn;
    private String spawnName;

    private int tier = 1;
    private double balance = 0.0;

    private long autoclaimCooldownSeconds = 0;
    private long lastUpkeepPaid = System.currentTimeMillis();
    private int unpaidDays = 0;

    private final Map<UUID, Role> members = new HashMap<>();
    private final Map<String, Set<String>> claims = new HashMap<>();

    private final Set<UUID> outlaws = new HashSet<>();
    private final Set<UUID> allies = new HashSet<>();
    private final Set<UUID> enemies = new HashSet<>();

    public Nation(UUID id, String name, UUID owner) {
        this.id = id;
        this.name = name;
        this.owner = owner;
        this.members.put(owner, Role.LEADER);
    }

    /* ===================== */
    /* BASIC INFO */
    /* ===================== */

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public UUID getLeader() {
        return owner;
    }

    public String getLeaderName() {
        OfflinePlayer p = Bukkit.getOfflinePlayer(owner);
        return p != null && p.getName() != null ? p.getName() : "Unknown";
    }

    public boolean isLeader(UUID uuid) {
        return uuid != null && uuid.equals(owner);
    }

    /* ===================== */
    /* TIER */
    /* ===================== */

    public int getTier() {
        return tier;
    }

    public void setTier(int tier) {
        this.tier = Math.max(1, tier); // ✅ FIX
    }

    /* ===================== */
    /* ECONOMY */
    /* ===================== */

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = Math.max(0, balance);
    }

    public void deposit(double amount) {
        if (amount > 0) balance += amount;
    }

    public boolean withdraw(double amount) {
        if (amount <= 0 || balance < amount) return false;
        balance -= amount;
        return true;
    }

    /* ===================== */
    /* HOME & SPAWN */
    /* ===================== */

    public Location getHome() {
        return home;
    }

    public void setHome(Location home) {
        this.home = home;
    }

    public Location getSpawn() {
        return spawn;
    }

    public void setSpawn(Location spawn) {
        this.spawn = spawn;
    }

    public String getSpawnName() {
        return spawnName;
    }

    public void setSpawnName(String spawnName) {
        this.spawnName = spawnName;
    }

    /* ===================== */
    /* MEMBERS */
    /* ===================== */

    public void addMember(UUID uuid, Role role) {
        members.put(uuid, role);
    }

    public boolean removeMember(UUID uuid) {
        if (uuid == null || uuid.equals(owner)) return false; // ✅ FIX
        return members.remove(uuid) != null;
    }

    public Role getRole(UUID uuid) {
        return members.getOrDefault(uuid, Role.MEMBER);
    }

    public Map<UUID, Role> getMembers() {
        return members;
    }

    public int getMemberCount() {
        return members.size();
    }

    /* ===================== */
    /* CLAIMS */
    /* ===================== */

    public void addClaim(String world, String chunkKey) {
        claims.computeIfAbsent(world, w -> new HashSet<>()).add(chunkKey);
    }

    public void removeClaim(String world, String chunkKey) {
        Set<String> set = claims.get(world);
        if (set == null) return;

        set.remove(chunkKey);
        if (set.isEmpty()) {
            claims.remove(world);
        }
    }

    public Set<String> getClaims(String world) {
        return claims.getOrDefault(world, Collections.emptySet());
    }

    public Map<String, Set<String>> getAllClaims() {
        return claims;
    }

    /* ===================== */
    /* RELATIONS */
    /* ===================== */

    public Set<UUID> getAllies() {
        return allies;
    }

    public Set<UUID> getEnemies() {
        return enemies;
    }

    /* ===================== */
    /* AUTOCLAIM */
    /* ===================== */

    public long getAutoclaimCooldownSeconds() {
        return autoclaimCooldownSeconds;
    }

    public void setAutoclaimCooldownSeconds(long seconds) {
        this.autoclaimCooldownSeconds = seconds;
    }

    /* ===================== */
    /* UPKEEP */
    /* ===================== */

    public long getLastUpkeepPaid() {
        return lastUpkeepPaid;
    }

    public void setLastUpkeepPaid(long time) {
        this.lastUpkeepPaid = time;
    }

    public int getUnpaidDays() {
        return unpaidDays;
    }

    public void setUnpaidDays(int days) {
        this.unpaidDays = days;
    }

    public String getLastUpkeepPaidString() {
        return new Date(lastUpkeepPaid).toString();
    }

    /* ===================== */
    /* ALLIANCE */
    /* ===================== */

    public UUID getAllianceId() {
        return allianceId;
    }

    public void setAllianceId(UUID allianceId) {
        this.allianceId = allianceId;
    }

    /* ===================== */
    /* OUTLAWS */
    /* ===================== */

    public boolean isOutlaw(UUID uuid) {
        return uuid != null && outlaws.contains(uuid);
    }

    public void addOutlaw(UUID uuid) {
        if (uuid != null) outlaws.add(uuid);
    }

    public void removeOutlaw(UUID uuid) {
        outlaws.remove(uuid);
    }

    public Set<UUID> getOutlaws() {
        return Collections.unmodifiableSet(outlaws);
    }
}
