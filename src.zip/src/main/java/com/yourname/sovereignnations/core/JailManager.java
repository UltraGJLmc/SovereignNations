package com.yourname.sovereignnations.core;

import com.yourname.sovereignnations.SovereignNations;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class JailManager {

    private static File jailFile;
    private static FileConfiguration jailConfig;

    // name -> Location (stored as world,x,y,z,yaw,pitch)
    private static final Map<String, Location> cells = new ConcurrentHashMap<>();

    // jailed players: uuid -> jailedUntil
    private static final Map<UUID, Long> jailed = new ConcurrentHashMap<>();

    public static void init(SovereignNations plugin) {
        jailFile = new File(plugin.getDataFolder(), "jails.yml");
        if (!jailFile.exists()) {
            plugin.saveResource("jails.yml", false);
        }
        jailConfig = YamlConfiguration.loadConfiguration(jailFile);
        loadAll();
    }

    public static void loadAll() {
        cells.clear();
        jailed.clear();

        if (jailConfig.contains("cells")) {
            ConfigurationSection sec = jailConfig.getConfigurationSection("cells");
            for (String name : sec.getKeys(false)) {
                ConfigurationSection c = sec.getConfigurationSection(name);
                try {
                    Location loc = new Location(
                            Bukkit.getWorld(c.getString("world")),
                            c.getDouble("x"), c.getDouble("y"), c.getDouble("z"),
                            (float) c.getDouble("yaw"), (float) c.getDouble("pitch")
                    );
                    cells.put(name, loc);
                } catch (Exception ignored) {}
            }
        }

        if (jailConfig.contains("jailed")) {
            ConfigurationSection j = jailConfig.getConfigurationSection("jailed");
            for (String u : j.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(u);
                    long until = j.getLong(u, 0L);
                    if (until > System.currentTimeMillis()) jailed.put(id, until);
                } catch (Exception ignored) {}
            }
        }
    }

    public static void saveAll() {
        ConfigurationSection csec = jailConfig.createSection("cells");
        for (Map.Entry<String, Location> e : cells.entrySet()) {
            Location l = e.getValue();
            ConfigurationSection ls = csec.createSection(e.getKey());
            ls.set("world", l.getWorld().getName());
            ls.set("x", l.getX());
            ls.set("y", l.getY());
            ls.set("z", l.getZ());
            ls.set("yaw", l.getYaw());
            ls.set("pitch", l.getPitch());
        }

        ConfigurationSection jsec = jailConfig.createSection("jailed");
        for (Map.Entry<UUID, Long> e : jailed.entrySet()) {
            jsec.set(e.getKey().toString(), e.getValue());
        }

        try {
            jailConfig.save(jailFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void addCell(String name, Location loc) {
        cells.put(name, loc);
        saveAll();
    }

    public static boolean removeCell(String name) {
        if (cells.remove(name) != null) { saveAll(); return true; }
        return false;
    }

    public static Location getCell(String name) { return cells.get(name); }

    public static boolean jailPlayer(UUID player, long seconds) {
        long until = System.currentTimeMillis() + seconds*1000L;
        jailed.put(player, until);
        saveAll();
        return true;
    }

    public static boolean releasePlayer(UUID player) {
        if (jailed.remove(player) != null) { saveAll(); return true; }
        return false;
    }

    public static boolean isJailed(UUID player) {
        Long until = jailed.get(player);
        if (until == null) return false;
        if (until < System.currentTimeMillis()) { jailed.remove(player); saveAll(); return false; }
        return true;
    }

    public static long getJailedUntil(UUID player) { return jailed.getOrDefault(player, 0L); }

    public static Set<String> getCellNames() { return Collections.unmodifiableSet(cells.keySet()); }
}