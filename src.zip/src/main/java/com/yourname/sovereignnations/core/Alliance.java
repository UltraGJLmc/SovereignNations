package com.yourname.sovereignnations.core;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class Alliance {

    public enum Role { LEADER, OFFICER, MEMBER }

    private final UUID id;
    private String name;
    private final Set<UUID> memberNationIds = Collections.synchronizedSet(new HashSet<>());
    private final Map<UUID, Role> memberRoles = new ConcurrentHashMap<>();

    public Alliance(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<UUID> getMembers() {
        return Collections.unmodifiableSet(memberNationIds);
    }

    public boolean addMember(UUID nationId) {
        boolean added = memberNationIds.add(nationId);
        if (added && !memberRoles.containsKey(nationId)) memberRoles.put(nationId, Role.MEMBER);
        return added;
    }

    public boolean removeMember(UUID nationId) {
        memberRoles.remove(nationId);
        return memberNationIds.remove(nationId);
    }

    public Role getRole(UUID nationId) {
        return memberRoles.getOrDefault(nationId, Role.MEMBER);
    }

    public void setRole(UUID nationId, Role role) {
        if (memberNationIds.contains(nationId)) memberRoles.put(nationId, role);
    }

    public Map<UUID, Role> getRoles() {
        return Collections.unmodifiableMap(memberRoles);
    }

}