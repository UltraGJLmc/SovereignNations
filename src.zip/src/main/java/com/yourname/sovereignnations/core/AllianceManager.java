package com.yourname.sovereignnations.core;

import com.yourname.sovereignnations.SovereignNations;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class AllianceManager {

    private static final Map<UUID, Alliance> alliances = new ConcurrentHashMap<>();
    // Invitations: targetNationId -> allianceId
    private static final Map<UUID, UUID> invites = new ConcurrentHashMap<>();

    private static File alliancesFile;
    private static FileConfiguration alliancesConfig;

    public static void init(SovereignNations plugin) {
        alliancesFile = new File(plugin.getDataFolder(), "alliances.yml");
        if (!alliancesFile.exists()) {
            plugin.saveResource("alliances.yml", false);
        }
        alliancesConfig = YamlConfiguration.loadConfiguration(alliancesFile);
        loadAll();
    }

    public static void loadAll() {
        alliances.clear();
        invites.clear();
        if (!alliancesConfig.contains("alliances")) return;
        ConfigurationSection top = alliancesConfig.getConfigurationSection("alliances");
        for (String idStr : top.getKeys(false)) {
            ConfigurationSection sec = top.getConfigurationSection(idStr);
            try {
                UUID id = UUID.fromString(sec.getString("id"));
                String name = sec.getString("name");
                Alliance a = new Alliance(id, name);
                if (sec.contains("members")) {
                    for (String n : sec.getStringList("members")) {
                        try {
                            a.addMember(UUID.fromString(n));
                        } catch (Exception ignored) {}
                    }
                }
                // load roles
                if (sec.contains("roles")) {
                    ConfigurationSection rolesSec = sec.getConfigurationSection("roles");
                    for (String nid : rolesSec.getKeys(false)) {
                        try {
                            UUID nationId = UUID.fromString(nid);
                            String roleName = rolesSec.getString(nid);
                            a.setRole(nationId, Alliance.Role.valueOf(roleName));
                        } catch (Exception ignored) {}
                    }
                }
                alliances.put(a.getId(), a);
            } catch (Exception ignored) {}
        }

        if (alliancesConfig.contains("invites")) {
            ConfigurationSection inv = alliancesConfig.getConfigurationSection("invites");
            for (String nationIdStr : inv.getKeys(false)) {
                try {
                    UUID nationId = UUID.fromString(nationIdStr);
                    UUID allianceId = UUID.fromString(inv.getString(nationIdStr));
                    invites.put(nationId, allianceId);
                } catch (Exception ignored) {}
            }
        }
    }

    public static void saveAll() {
        ConfigurationSection top = alliancesConfig.createSection("alliances");
        for (Alliance a : alliances.values()) {
            ConfigurationSection sec = top.createSection(a.getId().toString());
            sec.set("id", a.getId().toString());
            sec.set("name", a.getName());
            List<String> members = new ArrayList<>();
            for (UUID m : a.getMembers()) members.add(m.toString());
            sec.set("members", members);
            // save roles
            ConfigurationSection rolesSec = sec.createSection("roles");
            for (Map.Entry<UUID, Alliance.Role> rr : a.getRoles().entrySet()) {
                rolesSec.set(rr.getKey().toString(), rr.getValue().name());
            }
        }

        ConfigurationSection invSec = alliancesConfig.createSection("invites");
        for (Map.Entry<UUID, UUID> e : invites.entrySet()) {
            invSec.set(e.getKey().toString(), e.getValue().toString());
        }

        try {
            alliancesConfig.save(alliancesFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Alliance createAlliance(String name, Nation owner) {
        Alliance a = new Alliance(UUID.randomUUID(), name);
        a.addMember(owner.getId());
        a.setRole(owner.getId(), Alliance.Role.LEADER);
        alliances.put(a.getId(), a);
        owner.setAllianceId(a.getId());
        saveAll();
        return a;
    }

    public static Alliance getAlliance(UUID id) {
        return alliances.get(id);
    }

    public static Alliance getAllianceForNation(Nation nation) {
        if (nation.getAllianceId() == null) return null;
        return getAlliance(nation.getAllianceId());
    }

    public static void inviteNation(Alliance alliance, Nation target) {
        invites.put(target.getId(), alliance.getId());
        saveAll();
    }

    public static boolean hasInvite(Nation target) {
        return invites.containsKey(target.getId());
    }

    public static UUID getInvite(Nation target) {
        return invites.get(target.getId());
    }

    public static boolean acceptInvite(Nation target) {
        UUID aId = invites.remove(target.getId());
        if (aId == null) return false;
        Alliance a = getAlliance(aId);
        if (a == null) return false;
        a.addMember(target.getId());
        a.setRole(target.getId(), Alliance.Role.MEMBER);
        target.setAllianceId(a.getId());
        saveAll();
        NationManager.saveAll();
        return true;
    }

    public static boolean leaveAlliance(Nation n) {
        Alliance a = getAllianceForNation(n);
        if (a == null) return false;
        a.removeMember(n.getId());
        n.setAllianceId(null);
        saveAll();
        NationManager.saveAll();
        return true;
    }

    public static boolean setRole(Alliance a, UUID nationId, Alliance.Role role) {
        if (!a.getMembers().contains(nationId)) return false;
        a.setRole(nationId, role);
        saveAll();
        return true;
    }

    public static Alliance.Role getRoleForNation(Nation n) {
        Alliance a = getAllianceForNation(n);
        if (a == null) return null;
        return a.getRole(n.getId());
    }

    public static Collection<Alliance> getAllAlliances() {
        return alliances.values();
    }
}