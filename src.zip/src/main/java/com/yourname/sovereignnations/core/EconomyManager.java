package com.yourname.sovereignnations.core;

import com.yourname.sovereignnations.SovereignNations;

// Vault API import
import net.milkbowl.vault.economy.Economy;

// Bukkit imports (fully compatible with Paper)
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;




public class EconomyManager {

    private static Economy economy;

    /* ===================== */
    /* INITIALIZE VAULT ECONOMY */
    /* ===================== */
    public static boolean init(SovereignNations plugin) {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().severe("Vault is missing!");
            economy = null;
            return false;
        }

        var reg = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (reg == null) {
            plugin.getLogger().severe("No economy provider found via Vault!");
            economy = null;
            return false;
        }

        economy = reg.getProvider();

        plugin.getLogger().info("EconomyManager successfully initialized via Vault.");
        return economy != null;
    }

    public static boolean isAvailable() {
        return economy != null;
    }

    /* ===================== */
    /* PLAYER ECONOMY */
    /* ===================== */
    public static double getBalance(OfflinePlayer player) {
        if (economy == null) return 0.0;
        return economy.getBalance(player);
    }

    public static boolean withdrawPlayer(OfflinePlayer player, double amount) {
        if (economy == null) return false;
        if (amount <= 0) return false;
        if (economy.has(player, amount)) {
            economy.withdrawPlayer(player, amount);
            return true;
        }
        return false;
    }

    public static void depositPlayer(OfflinePlayer player, double amount) {
        if (economy == null) return;
        if (amount <= 0) return;
        economy.depositPlayer(player, amount);
    }

    /* ===================== */
    /* NATION ECONOMY */
    /* ===================== */
    public static double getBalance(Nation nation) {
        return nation.getBalance();
    }

    public static boolean withdrawNation(Nation nation, double amount) {
        if (amount <= 0) return false;
        if (nation.getBalance() >= amount) {
            nation.withdraw(amount);
            return true;
        }
        return false;
    }

    public static void depositNation(Nation nation, double amount) {
        if (amount <= 0) return;
        nation.deposit(amount);
    }

    /* ===================== */
    /* TRANSFER BETWEEN NATION AND PLAYER */
    /* ===================== */
    public static boolean transferPlayerToNation(OfflinePlayer player, Nation nation, double amount) {
        if (withdrawPlayer(player, amount)) {
            depositNation(nation, amount);
            return true;
        }
        return false;
    }

    public static boolean transferNationToPlayer(Nation nation, OfflinePlayer player, double amount) {
        if (withdrawNation(nation, amount)) {
            depositPlayer(player, amount);
            return true;
        }
        return false;
    }

    /* ===================== */
    /* UTILITY */
    /* ===================== */
    public static boolean hasEnoughPlayer(OfflinePlayer player, double amount) {
        if (economy == null) return false;
        return economy.has(player, amount);
    }

    public static boolean hasEnoughNation(Nation nation, double amount) {
        return nation.getBalance() >= amount;
    }

    public static String format(double amount) {
        if (economy == null) return String.format("%.2f", amount) + " $";
        return economy.format(amount);
    }
}
