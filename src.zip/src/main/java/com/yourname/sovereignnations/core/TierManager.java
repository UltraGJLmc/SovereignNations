package com.yourname.sovereignnations.core;

import com.yourname.sovereignnations.SovereignNations;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TierManager {

    private static final Map<String, Tier> tiers = new ConcurrentHashMap<>();
    private static SovereignNations plugin;

    public static void init(SovereignNations pl) {
        plugin = pl;
        loadFromConfig();
    }

    public static void loadFromConfig() {
        tiers.clear();
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.contains("tiers")) return;
        ConfigurationSection sec = cfg.getConfigurationSection("tiers");
        for (String name : sec.getKeys(false)) {
            ConfigurationSection t = sec.getConfigurationSection(name);
            int maxClaims = t.getInt("maxClaims", 10);
            int maxMembers = t.getInt("maxMembers", 10);
            double taxMod = t.getDouble("taxModifier", 1.0);
            Set<String> allowed = new HashSet<>();
            if (t.contains("allowedPlotTypes")) allowed.addAll(t.getStringList("allowedPlotTypes"));
            Tier tier = new Tier(name, maxClaims, maxMembers, taxMod, allowed);
            tiers.put(name.toLowerCase(), tier);
        }
    }

    public static Tier getTier(String name) {
        if (name == null) return null;
        return tiers.get(name.toLowerCase());
    }

    public static Tier getDefaultTier() {
        Tier t = getTier("default");
        if (t != null) return t;
        // fallback
        return new Tier("default", 10, 10, 1.0, Collections.emptySet());
    }

    public static Collection<Tier> getAllTiers() {
        return Collections.unmodifiableCollection(tiers.values());
    }

    public static void addTier(Tier t) {
        if (t == null) return;
        tiers.put(t.getName().toLowerCase(), t);
        saveToConfig();
    }

    public static boolean removeTier(String name) {
        if (name == null) return false;
        Tier removed = tiers.remove(name.toLowerCase());
        if (removed != null) {
            saveToConfig();
            return true;
        }
        return false;
    }

    public static void saveToConfig() {
        if (plugin == null) return;
        org.bukkit.configuration.file.FileConfiguration cfg = plugin.getConfig();
        org.bukkit.configuration.ConfigurationSection top = cfg.createSection("tiers");
        for (Tier t : tiers.values()) {
            org.bukkit.configuration.ConfigurationSection sec = top.createSection(t.getName());
            sec.set("maxClaims", t.getMaxClaims());
            sec.set("maxMembers", t.getMaxMembers());
            sec.set("taxModifier", t.getTaxModifier());
            sec.set("allowedPlotTypes", new ArrayList<>(t.getAllowedPlotTypes()));
        }
        plugin.saveConfig();


    }

    public static Tier getTier(int tierNumber) {
        return getTier(String.valueOf(tierNumber));
    }

}
