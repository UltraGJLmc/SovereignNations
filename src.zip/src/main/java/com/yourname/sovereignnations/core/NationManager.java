package com.yourname.sovereignnations.core;

import com.yourname.sovereignnations.SovereignNations;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class NationManager {

    private static final Map<String, Nation> nationsByName = new ConcurrentHashMap<>();
    private static final Map<UUID, Nation> nationsByPlayer = new ConcurrentHashMap<>();
    private static final Map<UUID, Nation> nationsById = new ConcurrentHashMap<>();

    private static SovereignNations plugin;

    /* ===================== */
    /* INIT */
    /* ===================== */

    public static void init(SovereignNations pluginInstance) {
        plugin = pluginInstance;

        nationsByName.clear();
        nationsByPlayer.clear();
        nationsById.clear();

        File dir = new File(plugin.getDataFolder(), "nations");
        if (!dir.exists()) dir.mkdirs();

        File[] files = dir.listFiles((d, n) -> n.endsWith(".yml"));
        if (files == null) return;

        for (File file : files) {
            loadNation(YamlConfiguration.loadConfiguration(file));
        }

        plugin.getLogger().info("Loaded " + nationsByName.size() + " nations.");
    }

    /* ===================== */
    /* LOAD */
    /* ===================== */

    private static void loadNation(FileConfiguration cfg) {
        try {
            UUID id = UUID.fromString(cfg.getString("id"));
            String name = cfg.getString("name");
            UUID leader = UUID.fromString(cfg.getString("leader"));

            Nation nation = new Nation(id, name, leader);

            nation.setBalance(cfg.getDouble("balance", 0));
            nation.setSpawnName(cfg.getString("spawn_name"));

            loadLocation(cfg.getConfigurationSection("spawn"), nation::setSpawn);

            ConfigurationSection members = cfg.getConfigurationSection("members");
            if (members != null) {
                for (String key : members.getKeys(false)) {
                    UUID u = UUID.fromString(key);
                    if (u.equals(leader)) continue;

                    Nation.Role role = Nation.Role.valueOf(
                            members.getString(key + ".role", "MEMBER")
                    );
                    nation.addMember(u, role);
                    nationsByPlayer.put(u, nation);
                }
            }

            nationsByName.put(name.toLowerCase(), nation);
            nationsById.put(id, nation);

        } catch (Exception e) {
            plugin.getLogger().severe("Failed to load nation file:");
            e.printStackTrace();
        }
    }

    /* ===================== */
    /* SAVE */
    /* ===================== */

    public static void saveAll() {
        File dir = new File(plugin.getDataFolder(), "nations");
        if (!dir.exists()) dir.mkdirs();

        for (Nation nation : nationsByName.values()) {
            saveNation(new File(dir, nation.getName().toLowerCase() + ".yml"), nation);
        }
    }

    private static void saveNation(File file, Nation nation) {
        FileConfiguration cfg = new YamlConfiguration();

        cfg.set("id", nation.getId().toString());
        cfg.set("name", nation.getName());
        cfg.set("leader", nation.getLeader().toString());
        cfg.set("balance", nation.getBalance());
        cfg.set("spawn_name", nation.getSpawnName());

        ConfigurationSection mem = cfg.createSection("members");
        nation.getMembers().forEach((u, r) ->
                mem.set(u.toString() + ".role", r.name())
        );

        saveLocation(cfg.createSection("spawn"), nation.getSpawn());

        try {
            cfg.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* ===================== */
    /* LOCATION */
    /* ===================== */

    private static void saveLocation(ConfigurationSection sec, Location loc) {
        if (loc == null) return;
        sec.set("world", loc.getWorld().getName());
        sec.set("x", loc.getX());
        sec.set("y", loc.getY());
        sec.set("z", loc.getZ());
        sec.set("yaw", loc.getYaw());
        sec.set("pitch", loc.getPitch());
    }

    private static void loadLocation(ConfigurationSection sec, Consumer<Location> consumer) {
        if (sec == null) return;
        World w = Bukkit.getWorld(sec.getString("world"));
        if (w == null) return;

        consumer.accept(new Location(
                w,
                sec.getDouble("x"),
                sec.getDouble("y"),
                sec.getDouble("z"),
                (float) sec.getDouble("yaw"),
                (float) sec.getDouble("pitch")
        ));
    }

    /* ===================== */
    /* API */
    /* ===================== */

    public static Nation getNation(String name) {
        return name == null ? null : nationsByName.get(name.toLowerCase());
    }

    public static Nation getNation(UUID player) {
        return nationsByPlayer.get(player);
    }

    public static Nation getNationById(UUID id) {
        return nationsById.get(id);
    }

    public static boolean nationExists(String name) {
        return name != null && nationsByName.containsKey(name.toLowerCase());
    }

    public static Nation createNation(String name, UUID leader) {
        if (nationExists(name)) return null;

        UUID id = UUID.randomUUID(); // ✅ FIXED
        Nation nation = new Nation(id, name, leader);
        nationsByPlayer.put(leader, nation); // ✅ REQUIRED


        nationsByName.put(name.toLowerCase(), nation);
        nationsById.put(id, nation);
        nationsByPlayer.put(leader, nation);

        return nation;
    }

    public static void removeNation(Nation nation) {
        if (nation == null) return;

        nationsByName.remove(nation.getName().toLowerCase());
        nationsById.remove(nation.getId());

        nation.getMembers().keySet().forEach(nationsByPlayer::remove);

        File file = new File(plugin.getDataFolder(),
                "nations/" + nation.getName().toLowerCase() + ".yml");
        if (file.exists()) file.delete();
    }

    public static Collection<Nation> getAllNations() {
        return Collections.unmodifiableCollection(nationsByName.values());
    }
}
