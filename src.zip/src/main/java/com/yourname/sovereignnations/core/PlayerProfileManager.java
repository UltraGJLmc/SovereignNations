package com.yourname.sovereignnations.core;

import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple manager for PlayerProfile objects.
 */
public class PlayerProfileManager {

    private static final Map<UUID, PlayerProfile> profiles = new ConcurrentHashMap<>();

    public static PlayerProfile getProfile(Player player) {
        return getProfile(player.getUniqueId(), player.getName());
    }

    public static PlayerProfile getProfile(UUID uuid, String playerName) {
        return profiles.computeIfAbsent(uuid, id -> new PlayerProfile(id, playerName));
    }

    public static void removeProfile(UUID uuid) {
        profiles.remove(uuid);
    }
}
