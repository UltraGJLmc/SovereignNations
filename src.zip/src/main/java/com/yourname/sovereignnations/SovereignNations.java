package com.yourname.sovereignnations;

import com.yourname.sovereignnations.claims.ClaimManager;
import com.yourname.sovereignnations.commands.*;
import com.yourname.sovereignnations.core.*;
import com.yourname.sovereignnations.gui.GUIManager;
import com.yourname.sovereignnations.hooks.DynmapHook;
import com.yourname.sovereignnations.hooks.VaultHook;
import com.yourname.sovereignnations.wars.WarManager;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class SovereignNations extends JavaPlugin {

    private static SovereignNations instance;
    private boolean enabledSuccessfully = false;

    public static SovereignNations get() {
        return instance;
    }

    /* ============================= */
    /* PLUGIN ENABLE */
    /* ============================= */
    @Override
    public void onEnable() {
        instance = this;

        try {
            ensureDataFolder();
            saveDefaultFiles();

            // Core systems
            RolePermissionManager.setup(this);
            TierManager.init(this);

            // Hooks
            VaultHook.init(this);
            DynmapHook.init(this);

            // Managers
            NationManager.init(this);
            ClaimManager.init(this);
            AllianceManager.init(this);
            WarManager.init(this);
            UpkeepManager.init(this);
            GUIManager.init(this);

            // Commands
            registerCommands();

            // Listeners
            registerListeners();

            enabledSuccessfully = true;
            getLogger().info("SovereignNations enabled successfully.");

        } catch (Throwable t) {
            getLogger().severe("=== SovereignNations FAILED TO ENABLE ===");
            t.printStackTrace();
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    /* ============================= */
    /* PLUGIN DISABLE */
    /* ============================= */
    @Override
    public void onDisable() {
        if (!enabledSuccessfully) return;

        try { NationManager.saveAll(); } catch (Throwable ignored) {}
        try { ClaimManager.saveAll(); } catch (Throwable ignored) {}
        try { WarManager.saveAll(); } catch (Throwable ignored) {}

        try { DynmapHook.shutdown(); } catch (Throwable ignored) {}

        enabledSuccessfully = false;
        instance = null;

        getLogger().info("SovereignNations disabled cleanly.");
    }

    /* ============================= */
    /* COMMANDS */
    /* ============================= */
    private void registerCommands() {

        if (getCommand("nation") != null)
            getCommand("nation").setExecutor(new NationCommand(this));

        if (getCommand("nationadmin") != null)
            getCommand("nationadmin").setExecutor(new NationAdminCommand(this));

        if (getCommand("alliance") != null)
            getCommand("alliance").setExecutor(new AllianceCommand(this));

        if (getCommand("war") != null)
            getCommand("war").setExecutor(new WarCommand(this));

        if (getCommand("snreload") != null)
            getCommand("snreload").setExecutor(new SNReloadCommand(this));
    }

    /* ============================= */
    /* LISTENERS */
    /* ============================= */
    private void registerListeners() {
        Bukkit.getPluginManager().registerEvents(new com.yourname.sovereignnations.listeners.ClaimListener(), this);
        Bukkit.getPluginManager().registerEvents(new com.yourname.sovereignnations.listeners.GUIListener(), this);
        Bukkit.getPluginManager().registerEvents(new com.yourname.sovereignnations.listeners.ChatInputListener(), this);
        Bukkit.getPluginManager().registerEvents(new com.yourname.sovereignnations.listeners.EnforcementListener(), this);
        Bukkit.getPluginManager().registerEvents(new com.yourname.sovereignnations.listeners.ChatRoutingListener(), this);
    }

    /* ============================= */
    /* FILE HANDLING */
    /* ============================= */
    private void ensureDataFolder() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            throw new IllegalStateException("Could not create plugin data folder");
        }
    }

    private void saveDefaultFiles() {
        saveIfMissing("config.yml");
        saveIfMissing("messages.yml");
        saveIfMissing("gui.yml");
        saveIfMissing("roles.yml");
        saveIfMissing("nations.yml");
        saveIfMissing("claims.yml");
        saveIfMissing("alliances.yml");
        saveIfMissing("wars.yml");
    }

    private void saveIfMissing(String name) {
        File file = new File(getDataFolder(), name);
        if (!file.exists()) saveResource(name, false);
    }

    /* ============================= */
    /* UTIL */
    /* ============================= */
    public FileConfiguration getFileConfig(String fileName) {
        File file = new File(getDataFolder(), fileName);
        if (!file.exists()) saveResource(fileName, false);
        return YamlConfiguration.loadConfiguration(file);
    }
}
