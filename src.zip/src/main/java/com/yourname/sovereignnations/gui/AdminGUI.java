package com.yourname.sovereignnations.gui;

import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.NationManager;
import com.yourname.sovereignnations.wars.WarManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class AdminGUI {

    private static final int SIZE = 54;
    private static final String TITLE = "§cSovereign Nations §8— §4Admin Panel";

    private AdminGUI() {}

    /* ============================= */
    /* OPEN MAIN ADMIN GUI */
    /* ============================= */

    public static void open(Player admin) {

        Inventory inv = Bukkit.createInventory(null, SIZE, TITLE);

        // ===== Nation Management =====
        inv.setItem(10, GUIManager.createItem(
                Material.BOOK,
                "§eView Nations",
                lore(
                        "§7Browse all nations",
                        "§7Click to manage"
                )
        ));

        inv.setItem(11, GUIManager.createItem(
                Material.BARRIER,
                "§cDelete Nation",
                lore(
                        "§7Force delete a nation",
                        "§cIrreversible"
                )
        ));

        inv.setItem(12, GUIManager.createItem(
                Material.NAME_TAG,
                "§6Rename Nation",
                lore(
                        "§7Force rename",
                        "§7Admin override"
                )
        ));

        // ===== War Management =====
        inv.setItem(14, GUIManager.createItem(
                Material.IRON_SWORD,
                "§4Active Wars",
                lore(
                        "§7View ongoing wars",
                        "§7Force end if needed"
                )
        ));

        inv.setItem(15, GUIManager.createItem(
                Material.TNT,
                "§cForce War",
                lore(
                        "§7Declare war manually",
                        "§cAdmin only"
                )
        ));

        // ===== Claim Management =====
        inv.setItem(19, GUIManager.createItem(
                Material.GRASS_BLOCK,
                "§aView Claims",
                lore(
                        "§7Inspect land claims",
                        "§7Per nation"
                )
        ));

        inv.setItem(20, GUIManager.createItem(
                Material.BARRIER,
                "§cClear Claims",
                lore(
                        "§7Force unclaim land",
                        "§cDangerous"
                )
        ));

        // ===== System =====
        inv.setItem(49, GUIManager.createItem(
                Material.REDSTONE_BLOCK,
                "§4Reload Plugin",
                lore(
                        "§7Reload configs",
                        "§cUse with caution"
                )
        ));

        inv.setItem(53, GUIManager.createItem(
                Material.BARRIER,
                "§cClose",
                lore("§7Exit admin panel")
        ));

        GUIManager.open(admin, inv);
    }

    /* ============================= */
    /* CLICK HANDLER */
    /* ============================= */

    public static void handleClick(Player admin, ItemStack clicked) {

        if (clicked == null || !clicked.hasItemMeta()) return;

        String name = clicked.getItemMeta().getDisplayName();

        switch (strip(name)) {

            case "View Nations" -> openNationList(admin);

            case "Delete Nation" ->
                    admin.sendMessage("§cUse §e/nationadmin delete <nation>");

            case "Rename Nation" ->
                    admin.sendMessage("§eUse §6/nationadmin rename <nation> <name>");

            case "Active Wars" ->
                    admin.sendMessage("§eActive wars: §c" + WarManager.getActiveWars().size());

            case "Force War" ->
                    admin.sendMessage("§cUse §e/war force <nation1> <nation2>");

            case "View Claims" ->
                    admin.sendMessage("§eUse §a/nationadmin claims <nation>");

            case "Clear Claims" ->
                    admin.sendMessage("§cUse §e/nationadmin clearclaims <nation>");

            case "Reload Plugin" ->
                    GUIManager.requireConfirmation(
                            admin,
                            "reload SovereignNations",
                            () -> {
                                Bukkit.getPluginManager()
                                        .getPlugin("SovereignNations")
                                        .reloadConfig();
                                admin.sendMessage("§aPlugin reloaded.");
                            }
                    );

            case "Close" -> admin.closeInventory();
        }
    }

    /* ============================= */
    /* NATION LIST */
    /* ============================= */

    private static void openNationList(Player admin) {

        Inventory inv = Bukkit.createInventory(null, SIZE, "§8All Nations");

        int slot = 0;
        String world = admin.getWorld().getName();

        for (Nation nation : NationManager.getAllNations()) {
            if (slot >= 45) break;

            inv.setItem(slot++, GUIManager.createItem(
                    Material.BOOK,
                    "§e" + nation.getName(),
                    lore(
                            "§7Leader: §f" + nation.getLeaderName(),
                            "§7Members: §f" + nation.getMembers().size(),
                            "§7Claims: §f" + nation.getClaims(world).size(),
                            "",
                            "§eClick for options"
                    )
            ));
        }

        inv.setItem(53, GUIManager.createItem(Material.BARRIER, "§cBack"));

        GUIManager.open(admin, inv);
    }

    /* ============================= */
    /* HELPERS */
    /* ============================= */

    private static List<String> lore(String... lines) {
        List<String> list = new ArrayList<>();
        for (String s : lines) list.add(s);
        return list;
    }

    private static String strip(String s) {
        return s.replaceAll("§.", "");
    }
}
