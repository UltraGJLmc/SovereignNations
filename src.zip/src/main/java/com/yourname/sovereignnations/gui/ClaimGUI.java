package com.yourname.sovereignnations.gui;

import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.claims.ClaimManager;
import com.yourname.sovereignnations.hooks.DynmapHook;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

/**
 * Simple claim manager GUI (players with nation access can perform quick actions).
 */
public class ClaimGUI {

    public static void openClaimGUI(Player player, Nation nation) {
        if (nation == null) {
            player.sendMessage("§cNation is null.");
            return;
        }

        Inventory inv = Bukkit.createInventory(null, 9 * 3, "Claim Manager: " + nation.getName());

        double cost = ClaimManager.getClaimCost();
        inv.setItem(11, GUIManager.createItem(Material.GOLD_NUGGET, "§aBuy Current Chunk", java.util.List.of("§7Cost: " + com.yourname.sovereignnations.core.EconomyManager.format(cost), "§7Click to begin purchase (requires confirm)")));
        inv.setItem(12, GUIManager.createItem(Material.GRASS_BLOCK, "§aFill Radius 1 (costs)", java.util.List.of("§7Cost per chunk: " + com.yourname.sovereignnations.core.EconomyManager.format(cost), "§7Click to purchase area (requires confirm)")));
        inv.setItem(13, GUIManager.createItem(Material.GRASS_BLOCK, "§aFill Radius 2 (costs)", java.util.List.of("§7Cost per chunk: " + com.yourname.sovereignnations.core.EconomyManager.format(cost), "§7Click to purchase area (requires confirm)")));
        inv.setItem(14, GUIManager.createItem(Material.GOLD_INGOT, "§6Toggle Current Chunk For Sale", java.util.List.of("§7Toggle for-sale for this chunk")));
        inv.setItem(15, GUIManager.createItem(Material.NAME_TAG, "§bRename Current Chunk", java.util.List.of("§7Rename the current chunk via chat")));

        inv.setItem(8, GUIManager.createItem(Material.OAK_DOOR, "§cClose"));

        player.openInventory(inv);
        GUIManager.registerOpen(player, inv);

    }
} 