package com.yourname.sovereignnations.gui;

import com.yourname.sovereignnations.core.*;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.UUID;

/**
 * GUI for regular players to manage their nation.
 */
public class NationGUI {

    private final Player player;
    private final Nation nation;
    private Inventory inventory;

    public NationGUI(Player player) {
        this.player = player;
        this.nation = PlayerProfileManager.getProfile(player).getNation();
        openGUI();
    }

    /* ===================== */
    /* OPEN GUI */
    /* ===================== */
    public void openGUI() {
        if (nation == null) {
            player.sendMessage("§cYou are not in a nation!");
            return;
        }

        inventory = Bukkit.createInventory(null, 9 * 3, "§6Nation Panel");

        // Nation Name
        inventory.setItem(0, createItem(Material.BOOK, "§eNation: " + nation.getName()));

        // Treasury
        inventory.setItem(1, createItem(Material.GOLD_INGOT, "§eTreasury: " + EconomyManager.format(nation.getBalance())));

        // Claims
        inventory.setItem(2, createItem(Material.GRASS_BLOCK, "§eClaims: " + nation.getClaims("world").size()));

        // Members
        inventory.setItem(3, createItem(Material.IRON_SWORD, "§eMembers: " + nation.getMembers().size()));

        // Upkeep info
        inventory.setItem(4, createItem(Material.CLOCK, "§eLast Upkeep Paid: " + nation.getLastUpkeepPaidString()));

        // Manage claims (open claim GUI)
        inventory.setItem(5, createItem(Material.DIAMOND_PICKAXE, "§aManage Claims"));

        // War (placeholder)
        inventory.setItem(6, createItem(Material.SHIELD, "§cWar Menu"));

        // Leave Nation
        inventory.setItem(7, createItem(Material.BARRIER, "§cLeave Nation"));

        // Close button
        inventory.setItem(8, createItem(Material.OAK_DOOR, "§cClose"));

        player.openInventory(inventory);
    }

    /* ===================== */
    /* HANDLE CLICK */
    /* ===================== */
    public void handleClick(int slot) {
        switch (slot) {
            case 5: // Manage Claims
                player.sendMessage("§aOpening claims management...");
                ClaimGUI.openClaimGUI(player, nation);
                break;
            case 6: // War
                player.sendMessage("§cWar menu coming soon!");
                break;
            case 7: // Leave Nation
                leaveNation();
                break;
            case 8: // Close
                player.closeInventory();
                break;
            default:
                break;
        }
    }

    /* ===================== */
    /* LEAVE NATION */
    /* ===================== */
    private void leaveNation() {
        UUID uuid = player.getUniqueId();
        PlayerProfile profile = PlayerProfileManager.getProfile(player);

        if (nation.isLeader(uuid)) {
            player.sendMessage("§cYou are the leader. You must transfer leadership before leaving!");
            return;
        }

        nation.removeMember(uuid);
        profile.setNation(null);
        player.sendMessage("§aYou have left the nation " + nation.getName());
        NationManager.saveAll();
    }

    /* ===================== */
    /* HELPER */
    /* ===================== */
    private ItemStack createItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            item.setItemMeta(meta);
        }
        return item;
    }
}
