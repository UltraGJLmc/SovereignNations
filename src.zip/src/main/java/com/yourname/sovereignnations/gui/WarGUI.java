package com.yourname.sovereignnations.gui;

import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.NationManager;
import com.yourname.sovereignnations.wars.WarManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class WarGUI {

    public static void openWarGUI(Player player, Nation playerNation) {
        Inventory inv = Bukkit.createInventory(null, 9 * 4, "War Menu: " + (playerNation != null ? playerNation.getName() : ""));
        int slot = 0;
        for (Nation n : NationManager.getAllNations()) {
            if (playerNation != null && n.getName().equalsIgnoreCase(playerNation.getName())) continue;
            inv.setItem(slot++, GUIManager.createItem(Material.WHITE_BANNER, "§e" + n.getName()));
            if (slot >= 27) break;
        }
        inv.setItem(35, GUIManager.createItem(Material.OAK_DOOR, "§cClose"));
        player.openInventory(inv);
        GUIManager.registerOpen(player, inv);

    }
}