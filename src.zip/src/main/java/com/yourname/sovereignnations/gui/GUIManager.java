package com.yourname.sovereignnations.gui;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.claims.ClaimManager;
import com.yourname.sovereignnations.core.*;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central GUI manager for SovereignNations.
 * FULL backward compatibility layer.
 */
public final class GUIManager {

    private static SovereignNations plugin;

    /* ===================== */
    /* OPEN INVENTORIES */
    /* ===================== */

    private static final Map<UUID, Inventory> openInventories = new ConcurrentHashMap<>();

    /* ===================== */
    /* PENDING CHAT INPUT */
    /* ===================== */

    public static final Map<UUID, Chunk> pendingRename = new ConcurrentHashMap<>();
    public static final Map<UUID, String> pendingCooldown = new ConcurrentHashMap<>();
    public static final Map<UUID, Runnable> pendingConfirmActions = new ConcurrentHashMap<>();
    public static final Map<UUID, String> pendingConfirmMessages = new ConcurrentHashMap<>();

    /* ===================== */
    /* INIT */
    /* ===================== */

    public static void init(SovereignNations pluginInstance) {
        plugin = pluginInstance;
        openInventories.clear();
        pendingRename.clear();
        pendingCooldown.clear();
        pendingConfirmActions.clear();
        pendingConfirmMessages.clear();
    }

    /* ===================== */
    /* OPEN STATE (UUID + PLAYER) */
    /* ===================== */

    public static boolean isOpen(Player player) {
        return openInventories.containsKey(player.getUniqueId());
    }

    public static boolean isOpen(UUID uuid) {
        return openInventories.containsKey(uuid);
    }

    public static void registerOpen(Player player, Inventory inventory) {
        openInventories.put(player.getUniqueId(), inventory);
    }

    public static void open(Player player, Inventory inventory) {
        player.openInventory(inventory);
        registerOpen(player, inventory);
    }

    public static void close(Player player) {
        openInventories.remove(player.getUniqueId());
        player.closeInventory();
    }

    public static void close(UUID uuid) {
        openInventories.remove(uuid);
    }

    /* ===================== */
    /* PLAYER GUI */
    /* ===================== */

    public static void openNationGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "Nation Menu");

        PlayerProfile profile = PlayerProfileManager.getProfile(player);
        Nation nation = profile != null ? profile.getNation() : null;

        if (nation != null) {
            inv.setItem(0, createItem(Material.BOOK, "§eNation: §f" + nation.getName()));
            inv.setItem(1, createItem(Material.GOLD_INGOT, "§eTreasury: §f" + EconomyManager.format(nation.getBalance())));
            inv.setItem(2, createItem(Material.GRASS_BLOCK, "§eClaims: §f" + nation.getClaims(player.getWorld().getName()).size()));
            inv.setItem(3, createItem(Material.IRON_SWORD, "§eMembers: §f" + nation.getMembers().size()));
            inv.setItem(4, createItem(Material.CLOCK, "§eLast Upkeep: §f" + nation.getLastUpkeepPaidString()));

            inv.setItem(11, createItem(Material.GRASS_BLOCK, "§aClaim Chunk"));
            inv.setItem(12, createItem(Material.RED_DYE, "§cUnclaim Chunk"));
            inv.setItem(13, createItem(Material.GOLD_NUGGET, "§6Toggle For Sale"));
            inv.setItem(14, createItem(Material.NAME_TAG, "§bRename Chunk"));
            inv.setItem(15, createItem(Material.DIAMOND_PICKAXE, "§aOpen Claim Manager"));

            inv.setItem(22, createItem(Material.SHIELD, "§cWar Menu"));
            inv.setItem(23, createItem(Material.BARRIER, "§cLeave Nation"));
        } else {
            inv.setItem(13, createItem(Material.PAPER, "§cYou are not in a nation"));
        }

        inv.setItem(26, createItem(Material.OAK_DOOR, "§cClose"));

        open(player, inv);
    }

    /* ===================== */
    /* CLICK HANDLER */
    /* ===================== */

    public static void handleClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!isOpen(player)) return;

        event.setCancelled(true);

        ItemStack item = event.getCurrentItem();
        if (item == null || item.getType().isAir()) return;

        String name = item.hasItemMeta() ? item.getItemMeta().getDisplayName() : "";
        String title = event.getView().getTitle();

        if (item.getType() == Material.OAK_DOOR || item.getType() == Material.BARRIER) {
            close(player);
            return;
        }

        if ("Nation Menu".equals(title)) {
            if (name.contains("Claim")) player.performCommand("nation claim");
            else if (name.contains("Unclaim")) player.performCommand("nation unclaim");
            else if (name.contains("For Sale")) ClaimManager.toggleForSale(player.getLocation().getChunk());
            else if (name.contains("Rename")) {
                pendingRename.put(player.getUniqueId(), player.getLocation().getChunk());
                player.sendMessage("§eType the new name in chat.");
            }
            close(player);
        }
    }

    /* ===================== */
    /* CONFIRMATION */
    /* ===================== */

    public static void requireConfirmation(Player player, String message, Runnable action) {
        UUID id = player.getUniqueId();

        pendingConfirmActions.put(id, action);
        pendingConfirmMessages.put(id, message);

        player.sendMessage("§eType §aconfirm §eto " + message + " (§ccancel§e to abort)");
        sendTitle(player, "Confirm Action", message);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (pendingConfirmActions.remove(id) != null) {
                pendingConfirmMessages.remove(id);
                player.sendMessage("§cConfirmation timed out.");
            }
        }, 20L * 30);
    }

    /* ===================== */
    /* UTIL */
    /* ===================== */

    public static ItemStack createItem(Material material, String name) {
        return createItem(material, name, Collections.emptyList());
    }

    public static ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore != null && !lore.isEmpty()) meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    public static void sendTitle(Player player, String title, String subtitle) {
        try {
            player.sendTitle(title == null ? "" : title, subtitle == null ? "" : subtitle, 5, 40, 10);
        } catch (Throwable t) {
            if (subtitle != null) player.sendMessage(subtitle);
        }
    }

    public static void openAdminGUI(Player player) {
        AdminGUI.open(player);
    }
}
