package com.yourname.sovereignnations.chat;

public enum ChatChannel {
    PUBLIC,
    NATION,
    ALLIANCE
}