package com.yourname.sovereignnations.chat;

import com.yourname.sovereignnations.core.Alliance;
import com.yourname.sovereignnations.core.AllianceManager;
import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.NationManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class ChatManager {

    public static void sendNationMessage(Nation nation, Player sender, String message) {
        String prefix = ChatColor.DARK_GREEN + "[Nation] " + ChatColor.AQUA + nation.getName() + ChatColor.WHITE + " ";
        String full = prefix + ChatColor.YELLOW + sender.getName() + ChatColor.WHITE + ": " + message;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (nation.getMembers().containsKey(p.getUniqueId())) {
                p.sendMessage(full);
            }
        }
    }

    public static void sendAllianceMessage(Alliance alliance, Player sender, String message) {
        String prefix = ChatColor.DARK_PURPLE + "[Alliance] " + ChatColor.AQUA + alliance.getName() + ChatColor.WHITE + " ";
        String full = prefix + ChatColor.YELLOW + sender.getName() + ChatColor.WHITE + ": " + message;
        for (Player p : Bukkit.getOnlinePlayers()) {
            // if player's nation is in alliance
            if (p != null && p.isOnline()) {
                // check player's nation
                Nation n = NationManager.getNation(p.getUniqueId());
                if (n != null && alliance.getMembers().contains(n.getId())) {
                    p.sendMessage(full);
                }
            }
        }
    }
}