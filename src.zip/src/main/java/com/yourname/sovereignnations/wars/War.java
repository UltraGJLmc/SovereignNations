package com.yourname.sovereignnations.wars;

import java.util.UUID;
import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.NationManager;

/**
 * Represents a war between two nations.
 */
public class War {

    private final UUID attackerId;
    private final UUID defenderId;

    private final long startTime;
    private long endTime;

    private boolean active;
    private boolean pvpEnabled; // Can be used to allow PvP in claims

    /* ===================== */
    /* CONSTRUCTOR */
    /* ===================== */
    public War(Nation attacker, Nation defender) {
        this.attackerId = attacker.getId();
        this.defenderId = defender.getId();
        this.startTime = System.currentTimeMillis();
        this.active = true;
        this.pvpEnabled = true; // default allow PvP
    }

    public War(UUID attackerId, UUID defenderId, long startTime, long endTime, boolean active, boolean pvpEnabled) {
        this.attackerId = attackerId;
        this.defenderId = defenderId;
        this.startTime = startTime;
        this.endTime = endTime;
        this.active = active;
        this.pvpEnabled = pvpEnabled;
    }

    /* ===================== */
    /* GETTERS */
    /* ===================== */
    public Nation getAttacker() {
        return NationManager.getNationById(attackerId);
    }

    public Nation getDefender() {
        return NationManager.getNationById(defenderId);
    }

    public long getStartTime() {
        return startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public boolean isActive() {
        return active;
    }

    public boolean isPvpEnabled() {
        return pvpEnabled;
    }

    /* ===================== */
    /* SETTERS */
    /* ===================== */
    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setPvpEnabled(boolean pvpEnabled) {
        this.pvpEnabled = pvpEnabled;
    }

    /* ===================== */
    /* UTILITIES */
    /* ===================== */

    /**
     * Checks if a nation is involved in this war.
     */
    public boolean involves(Nation nation) {
        UUID id = nation.getId();
        return attackerId.equals(id) || defenderId.equals(id);
    }

    /**
     * Returns a human-readable summary of the war.
     */
    @Override
    public String toString() {
        String attackerName = getAttacker() != null ? getAttacker().getName() : "Unknown";
        String defenderName = getDefender() != null ? getDefender().getName() : "Unknown";

        return "[War] " + attackerName + " vs " + defenderName +
                " | Active: " + active +
                " | PvP: " + (pvpEnabled ? "Enabled" : "Disabled");
    }
}
