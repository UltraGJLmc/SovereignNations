package com.yourname.sovereignnations.wars;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.claims.Claim;
import com.yourname.sovereignnations.claims.ClaimManager;
import com.yourname.sovereignnations.hooks.DynmapHook;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Manages all wars between nations.
 */
public class WarManager {

    private static SovereignNations plugin;

    // Thread-safe list of active wars
    private static final List<War> activeWars = new CopyOnWriteArrayList<>();
    private static final List<War> warHistory = new ArrayList<>();

    /* ===================== */
    /* INITIALIZE */
    /* ===================== */
    public static void init(SovereignNations pluginInstance) {
        plugin = pluginInstance;
        plugin.getLogger().info("WarManager initialized.");
        // Load persisted wars
        loadAll();
    }

    /* ===================== */
    /* START WAR */
    /* ===================== */
    public static boolean startWar(Nation attacker, Nation defender) {
        if (isAtWar(attacker, defender)) return false;

        War war = new War(attacker, defender);
        activeWars.add(war);

        // Notify players
        broadcastToNation(attacker, "§cYour nation has declared war on " + defender.getName() + "!");
        broadcastToNation(defender, "§cYour nation is now at war with " + attacker.getName() + "!");

        // Optional: update Dynmap markers
        DynmapHook.refreshAll();

        return true;
    }

    /* ===================== */
    /* END WAR */
    /* ===================== */
    public static boolean endWar(War war) {
        if (!activeWars.contains(war)) return false;

        war.setActive(false);
        war.setEndTime(System.currentTimeMillis());
        activeWars.remove(war);
        warHistory.add(war);

        // Notify players
        broadcastToNation(war.getAttacker(), "§aThe war against " + war.getDefender().getName() + " has ended!");
        broadcastToNation(war.getDefender(), "§aThe war against " + war.getAttacker().getName() + " has ended!");

        // Optional: refresh Dynmap
        DynmapHook.refreshAll();

        return true;
    }

    /* ===================== */
    /* GET ACTIVE WARS */
    /* ===================== */
    public static List<War> getActiveWars() {
        return new ArrayList<>(activeWars);
    }

    public static List<War> getWarHistory() {
        return new ArrayList<>(warHistory);
    }

    /* ===================== */
    /* CHECK IF NATIONS ARE AT WAR */
    /* ===================== */
    public static boolean isAtWar(Nation n1, Nation n2) {
        for (War war : activeWars) {
            if ((war.getAttacker().equals(n1) && war.getDefender().equals(n2)) ||
                    (war.getAttacker().equals(n2) && war.getDefender().equals(n1))) {
                return true;
            }
        }
        return false;
    }

    /* ===================== */
    /* CHECK IF CHUNK IS WAR ZONE */
    /* ===================== */
    public static boolean isChunkWarZone(Chunk chunk) {
        Claim claim = ClaimManager.getClaim(chunk);
        if (claim == null) return false;

        for (War war : activeWars) {
            if (war.involves(claim.getNation())) return true;
        }
        return false;
    }

    /* ===================== */
    /* BROADCAST UTILITY */
    /* ===================== */
    private static void broadcastToNation(Nation nation, String message) {
        for (UUID memberId : nation.getMembers().keySet()) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null && member.isOnline()) {
                member.sendMessage(message);
            }
        }
    }

    /* ===================== */
    /* GET WAR INVOLVING NATION */
    /* ===================== */
    public static List<War> getWars(Nation nation) {
        List<War> list = new ArrayList<>();
        for (War war : activeWars) {
            if (war.involves(nation)) list.add(war);
        }
        return list;
    }

    /* ===================== */
    /* SAVE / LOAD */
    /* ===================== */
    public static void saveAll() {
        if (plugin == null) return;
        java.io.File file = new java.io.File(plugin.getDataFolder(), "wars.yml");
        org.bukkit.configuration.file.FileConfiguration cfg = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(file);

        List<java.util.Map<String, Object>> out = new ArrayList<>();
        for (War w : warHistory) {
            java.util.Map<String, Object> m = new java.util.HashMap<>();
            m.put("attacker", w.getAttacker() != null ? w.getAttacker().getId().toString() : null);
            m.put("defender", w.getDefender() != null ? w.getDefender().getId().toString() : null);
            m.put("startTime", w.getStartTime());
            m.put("endTime", w.getEndTime());
            m.put("active", w.isActive());
            m.put("pvpEnabled", w.isPvpEnabled());
            out.add(m);
        }
        cfg.set("wars", out);
        try {
            cfg.save(file);
            plugin.getLogger().info("Saved " + out.size() + " wars to wars.yml");
        } catch (java.io.IOException e) {
            plugin.getLogger().severe("Failed to save wars.yml: " + e.getMessage());
        }
    }

    /* ===================== */
    /* LOAD WARS */
    /* ===================== */
    public static void loadAll() {
        if (plugin == null) return;
        java.io.File file = new java.io.File(plugin.getDataFolder(), "wars.yml");
        if (!file.exists()) return;
        org.bukkit.configuration.file.FileConfiguration cfg = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(file);
        if (!cfg.contains("wars")) return;

        List<java.util.Map<?, ?>> list = cfg.getMapList("wars");
        warHistory.clear();
        activeWars.clear();

        for (java.util.Map<?, ?> m : list) {
            try {
                UUID attacker = m.get("attacker") != null ? UUID.fromString(m.get("attacker").toString()) : null;
                UUID defender = m.get("defender") != null ? UUID.fromString(m.get("defender").toString()) : null;
                long start = m.get("startTime") != null ? Long.parseLong(m.get("startTime").toString()) : System.currentTimeMillis();
                long end = m.get("endTime") != null ? Long.parseLong(m.get("endTime").toString()) : 0L;
                boolean active = m.get("active") != null && Boolean.parseBoolean(m.get("active").toString());
                boolean pvp = m.get("pvpEnabled") != null && Boolean.parseBoolean(m.get("pvpEnabled").toString());

                if (attacker != null && defender != null) {
                    War w = new War(attacker, defender, start, end, active, pvp);
                    warHistory.add(w);
                    if (active) activeWars.add(w);
                }
            } catch (Throwable t) {
                // skip malformed entries
            }
        }

        plugin.getLogger().info("Loaded " + warHistory.size() + " wars from wars.yml");
    }
}
