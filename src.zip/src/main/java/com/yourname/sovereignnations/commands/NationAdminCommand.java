package com.yourname.sovereignnations.commands;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.core.*;
import com.yourname.sovereignnations.gui.AdminGUI;
import com.yourname.sovereignnations.claims.Claim;
import com.yourname.sovereignnations.claims.ClaimManager;
import com.yourname.sovereignnations.hooks.DynmapHook;
import com.yourname.sovereignnations.wars.War;
import com.yourname.sovereignnations.wars.WarManager;

// Bukkit imports (fully compatible with Paper)
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;




/**
 * Handles all admin nation commands.
 * Example: /nationadmin remove, /nationadmin war, /nationadmin upkeep, etc.
 */
public class NationAdminCommand implements CommandExecutor {

    private final SovereignNations plugin;

    public NationAdminCommand(SovereignNations plugin) {
        this.plugin = plugin;
        plugin.getCommand("nationadmin").setExecutor(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use admin commands.");
            return true;
        }

        Player admin = (Player) sender;

        if (!admin.hasPermission("sovereignnations.admin")) {
            admin.sendMessage(ChatColor.RED + "You do not have permission to use this command!");
            return true;
        }

        if (args.length == 0) {
            admin.sendMessage(ChatColor.GOLD + "=== Nation Admin Commands ===");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin gui - Open admin GUI");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin remove <nation> - Remove a nation");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin war start <attacker> <defender> - Start war");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin war end <attacker> <defender> - End war");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin upkeep <nation> - Force upkeep payment");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin claim clear <nation> - Clear all claims");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin tier list - List tier definitions");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin tier create <name> <maxClaims> <maxMembers> <taxModifier> - Create a tier");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin tier delete <name> - Delete a tier");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin roles list - List role permissions");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin roles add <role> <permission> - Add permission to role");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin roles remove <role> <permission> - Remove permission from role");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin roles reload - Reload roles.yml from disk");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin autoclaim get <nation> - Show per-nation cooldown (seconds)");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin autoclaim set <nation> <seconds|0> - Set per-nation cooldown in seconds (0 = use global)");
            admin.sendMessage(ChatColor.AQUA + "/nationadmin autoclaim reset <nation> - Remove per-nation override and use global default");
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "gui":
                com.yourname.sovereignnations.gui.GUIManager.openAdminGUI(admin);
                break;

            case "remove":
                if (args.length < 2) {
                    admin.sendMessage(ChatColor.RED + "Usage: /nationadmin remove <nation>");
                    return true;
                }
                Nation removeNation = NationManager.getNation(args[1]);
                if (removeNation == null) {
                    admin.sendMessage(ChatColor.RED + "Nation not found!");
                    return true;
                }
                // Require typed confirmation to remove a nation
                com.yourname.sovereignnations.gui.GUIManager.requireConfirmation(admin, "remove nation " + removeNation.getName(), () -> {
                    NationManager.removeNation(removeNation);
                    admin.sendMessage(ChatColor.GREEN + "Nation " + removeNation.getName() + " has been removed!");
                });
                break;
                

            case "war":
                if (args.length < 4) {
                    admin.sendMessage(ChatColor.RED + "Usage: /nationadmin war <start|end> <attacker> <defender>");
                    return true;
                }
                Nation attacker = NationManager.getNation(args[2]);
                Nation defender = NationManager.getNation(args[3]);
                if (attacker == null || defender == null) {
                    admin.sendMessage(ChatColor.RED + "Invalid nation(s) specified!");
                    return true;
                }
                if (args[1].equalsIgnoreCase("start")) {
                    if (WarManager.startWar(attacker, defender)) {
                        admin.sendMessage(ChatColor.GREEN + "War started between " + attacker.getName() + " and " + defender.getName());
                    } else {
                        admin.sendMessage(ChatColor.RED + "A war already exists between these nations!");
                    }
                } else if (args[1].equalsIgnoreCase("end")) {
                    boolean ended = false;
                    for (War war : WarManager.getWars(attacker)) {
                        if (war.involves(defender)) {
                            WarManager.endWar(war);
                            ended = true;
                        }
                    }
                    if (ended) {
                        admin.sendMessage(ChatColor.GREEN + "War ended between " + attacker.getName() + " and " + defender.getName());
                    } else {
                        admin.sendMessage(ChatColor.RED + "No active war exists between these nations!");
                    }
                }
                break;

            case "upkeep":
                if (args.length < 2) {
                    admin.sendMessage(ChatColor.RED + "Usage: /nationadmin upkeep <nation>");
                    return true;
                }
                Nation upkeepNation = NationManager.getNation(args[1]);
                if (upkeepNation == null) {
                    admin.sendMessage(ChatColor.RED + "Nation not found!");
                    return true;
                }
                UpkeepManager.performUpkeep(upkeepNation);
                admin.sendMessage(ChatColor.GREEN + "Upkeep forced for " + upkeepNation.getName());
                break;

            case "claim":
                // Support admin marking current chunk as for-sale
                if (args.length >= 2 && args[1].equalsIgnoreCase("markforsale")) {
                    org.bukkit.Chunk c = admin.getLocation().getChunk();
                    boolean now = ClaimManager.toggleForSale(c);
                    admin.sendMessage(ChatColor.GREEN + "Chunk for-sale toggled: " + (now ? "ON (members only)" : "OFF"));
                    return true;
                }

                if (args.length < 3 || !args[1].equalsIgnoreCase("clear")) {
                    admin.sendMessage(ChatColor.RED + "Usage: /nationadmin claim clear <nation> OR /nationadmin claim markforsale");
                    return true;
                }
                Nation claimNation = NationManager.getNation(args[2]);
                if (claimNation == null) {
                    admin.sendMessage(ChatColor.RED + "Nation not found!");
                    return true;
                }
                // Require typed confirmation before clearing all claims
                com.yourname.sovereignnations.gui.GUIManager.requireConfirmation(admin, "clear all claims for " + claimNation.getName(), () -> {
                    for (Claim claim : ClaimManager.getAllClaims(claimNation)) {
                        ClaimManager.unclaimChunk(claim);
                        DynmapHook.removeClaimMarker(claim);
                    }
                    admin.sendMessage(ChatColor.GREEN + "All claims cleared for " + claimNation.getName());
                });
                return true;
                

            case "tier":
                if (args.length < 2) { admin.sendMessage(ChatColor.RED + "Usage: /nationadmin tier <list|create|delete>"); return true; }
                String ta = args[1].toLowerCase();
                switch (ta) {
                    case "list":
                        admin.sendMessage(ChatColor.GOLD + "=== Tiers: " + com.yourname.sovereignnations.core.TierManager.getAllTiers().size() + " ===");
                        for (com.yourname.sovereignnations.core.Tier t : com.yourname.sovereignnations.core.TierManager.getAllTiers()) {
                            admin.sendMessage(ChatColor.AQUA + t.getName() + ChatColor.GRAY + " - Claims: " + t.getMaxClaims() + " Members: " + t.getMaxMembers() + " TaxMod: " + t.getTaxModifier());
                        }
                        break;
                    case "create":
                        if (args.length < 6) { admin.sendMessage(ChatColor.RED + "Usage: /nationadmin tier create <name> <maxClaims> <maxMembers> <taxModifier>"); return true; }
                        try {
                            String tname = args[2];
                            int mc = Integer.parseInt(args[3]);
                            int mm = Integer.parseInt(args[4]);
                            double tm = Double.parseDouble(args[5]);
                            com.yourname.sovereignnations.core.Tier newt = new com.yourname.sovereignnations.core.Tier(tname, mc, mm, tm, java.util.Collections.emptySet());
                            com.yourname.sovereignnations.core.TierManager.addTier(newt);
                            admin.sendMessage(ChatColor.GREEN + "Tier " + tname + " created.");
                        } catch (Exception ex) {
                            admin.sendMessage(ChatColor.RED + "Invalid numbers provided.");
                        }
                        break;
                    case "delete":
                        if (args.length < 3) { admin.sendMessage(ChatColor.RED + "Usage: /nationadmin tier delete <name>"); return true; }
                        if (com.yourname.sovereignnations.core.TierManager.removeTier(args[2])) admin.sendMessage(ChatColor.GREEN + "Tier removed."); else admin.sendMessage(ChatColor.RED + "No such tier.");
                        break;
                    default:
                        admin.sendMessage(ChatColor.RED + "Unknown tier operation.");
                        break;
                }
                break;

            case "roles":
                if (args.length < 2) { admin.sendMessage(ChatColor.RED + "Usage: /nationadmin roles <list|add|remove|reload>"); return true; }
                String ra = args[1].toLowerCase();
                switch (ra) {
                    case "list":
                        admin.sendMessage(ChatColor.GOLD + "=== Roles & Permissions ===");
                        for (com.yourname.sovereignnations.core.Nation.Role r : com.yourname.sovereignnations.core.Nation.Role.values()) {
                            admin.sendMessage(ChatColor.AQUA + r.name() + ChatColor.GRAY + " - " + com.yourname.sovereignnations.core.RolePermissionManager.getPermissions(r).toString());
                        }
                        break;
                    case "add":
                        if (args.length < 4) { admin.sendMessage(ChatColor.RED + "Usage: /nationadmin roles add <role> <permission>"); return true; }
                        try {
                            com.yourname.sovereignnations.core.Nation.Role role = com.yourname.sovereignnations.core.Nation.Role.valueOf(args[2].toUpperCase());
                            com.yourname.sovereignnations.core.RolePermissionManager.addPermission(role, args[3]);
                            admin.sendMessage(ChatColor.GREEN + "Permission added.");
                        } catch (Exception ex) { admin.sendMessage(ChatColor.RED + "Invalid role name."); }
                        break;
                    case "remove":
                        if (args.length < 4) { admin.sendMessage(ChatColor.RED + "Usage: /nationadmin roles remove <role> <permission>"); return true; }
                        try {
                            com.yourname.sovereignnations.core.Nation.Role role = com.yourname.sovereignnations.core.Nation.Role.valueOf(args[2].toUpperCase());
                            com.yourname.sovereignnations.core.RolePermissionManager.removePermission(role, args[3]);
                            admin.sendMessage(ChatColor.GREEN + "Permission removed.");
                        } catch (Exception ex) { admin.sendMessage(ChatColor.RED + "Invalid role name."); }
                        break;
                    case "reload":
                        com.yourname.sovereignnations.core.RolePermissionManager.reload();
                        admin.sendMessage(ChatColor.GREEN + "Roles reloaded from disk.");
                        break;
                    default:
                        admin.sendMessage(ChatColor.RED + "Unknown roles operation.");
                        break;
                }
                break;

            case "autoclaim":
                if (args.length < 3) { admin.sendMessage(ChatColor.RED + "Usage: /nationadmin autoclaim <get|set|reset> <nation> [seconds]"); return true; }
                String op = args[1].toLowerCase();
                String nname = args[2];
                Nation na = NationManager.getNation(nname);
                if (na == null) { admin.sendMessage(ChatColor.RED + "Nation not found!"); return true; }

                if (op.equals("get")) {
                    long s = na.getAutoclaimCooldownSeconds();
                    if (s < 0) admin.sendMessage(ChatColor.AQUA + "Nation " + na.getName() + " uses global autoclaim cooldown."); else if (s == -2) admin.sendMessage(ChatColor.AQUA + "Nation " + na.getName() + " has autoclaim disabled."); else admin.sendMessage(ChatColor.AQUA + "Nation " + na.getName() + " autoclaim cooldown: " + s + " seconds.");
                } else if (op.equals("set")) {
                    if (args.length < 4) { admin.sendMessage(ChatColor.RED + "Usage: /nationadmin autoclaim set <nation> <seconds> (0 = global, -1 = disabled)"); return true; }
                    try {
                        long secs = Long.parseLong(args[3]);
                        if (secs < 0) {
                            if (secs == -1) { na.setAutoclaimCooldownSeconds(-2L); admin.sendMessage(ChatColor.GREEN + "Autoclaim disabled for " + na.getName()); }
                            else { admin.sendMessage(ChatColor.RED + "Seconds must be >= -1."); }
                        } else {
                            na.setAutoclaimCooldownSeconds(secs == 0 ? -1L : secs);
                            admin.sendMessage(ChatColor.GREEN + "Set autoclaim cooldown for " + na.getName() + " to " + (secs == 0 ? "global" : secs + " seconds"));
                        }
                        NationManager.saveAll();
                    } catch (Exception ex) { admin.sendMessage(ChatColor.RED + "Invalid number."); }
                } else if (op.equals("reset")) {
                    na.setAutoclaimCooldownSeconds(-1L);
                    NationManager.saveAll();
                    admin.sendMessage(ChatColor.GREEN + "Per-nation autoclaim cooldown cleared for " + na.getName());
                } else {
                    admin.sendMessage(ChatColor.RED + "Unknown autoclaim sub-op. Use get|set|reset");
                }
                break;

            default:
                admin.sendMessage(ChatColor.RED + "Unknown subcommand. Type /nationadmin for help.");
                break;
        }

        return true;
    }
}

