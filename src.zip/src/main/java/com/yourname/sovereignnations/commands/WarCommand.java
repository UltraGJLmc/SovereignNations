package com.yourname.sovereignnations.commands;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.core.NationManager;
import com.yourname.sovereignnations.wars.WarManager;
import com.yourname.sovereignnations.wars.War;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class WarCommand implements CommandExecutor {

    private final SovereignNations plugin;

    public WarCommand(SovereignNations plugin) {
        this.plugin = plugin;
        if (plugin.getCommand("war") != null) {
            plugin.getCommand("war").setExecutor(this);
        } else {
            plugin.getLogger().warning("Command 'war' is not defined in plugin.yml — war commands disabled.");
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("sovereignnations.admin")) {
            player.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
            return true;
        }
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Usage: /war <start|end> <attacker> <defender>");
            return true;
        }
        String act = args[0].toLowerCase();
        String a = args[1];
        String b = args[2];
        com.yourname.sovereignnations.core.Nation attacker = NationManager.getNation(a);
        com.yourname.sovereignnations.core.Nation defender = NationManager.getNation(b);
        if (attacker == null || defender == null) {
            player.sendMessage(ChatColor.RED + "Invalid nation(s) specified.");
            return true;
        }
        if (act.equals("start")) {
            if (WarManager.startWar(attacker, defender)) {
                player.sendMessage(ChatColor.GREEN + "War started between " + attacker.getName() + " and " + defender.getName());
            } else {
                player.sendMessage(ChatColor.RED + "A war already exists between these nations.");
            }
        } else if (act.equals("end")) {
            boolean ended = false;
            for (War war : WarManager.getWars(attacker)) {
                if (war.involves(defender)) {
                    WarManager.endWar(war);
                    ended = true;
                }
            }
            if (ended) player.sendMessage(ChatColor.GREEN + "War ended between " + attacker.getName() + " and " + defender.getName());
            else player.sendMessage(ChatColor.RED + "No active war between those nations.");
        }
        return true;
    }
}