package com.yourname.sovereignnations.commands;

import com.yourname.sovereignnations.SovereignNations;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class SNReloadCommand implements CommandExecutor {

    private final SovereignNations plugin;

    public SNReloadCommand(SovereignNations plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        sender.sendMessage("§eReloading SovereignNations...");

        plugin.reloadConfig();

        sender.sendMessage("§aSovereignNations reloaded.");
        return true;
    }
}
