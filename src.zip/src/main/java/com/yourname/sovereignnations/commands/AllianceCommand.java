package com.yourname.sovereignnations.commands;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.core.Alliance;
import com.yourname.sovereignnations.core.AllianceManager;
import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.NationManager;
import com.yourname.sovereignnations.core.PlayerProfile;
import com.yourname.sovereignnations.core.PlayerProfileManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class AllianceCommand implements CommandExecutor {

    public AllianceCommand(SovereignNations plugin) {
        plugin.getCommand("alliance").setExecutor(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use alliance commands.");
            return true;
        }
        Player p = (Player) sender;
        UUID uuid = p.getUniqueId();
        PlayerProfile profile = PlayerProfileManager.getProfile(p);

        if (args.length == 0) {
            p.sendMessage(ChatColor.GOLD + "=== Alliance Commands ===");
            p.sendMessage(ChatColor.AQUA + "/alliance create <name>");
            p.sendMessage(ChatColor.AQUA + "/alliance invite <nation>");
            p.sendMessage(ChatColor.AQUA + "/alliance accept");
            p.sendMessage(ChatColor.AQUA + "/alliance leave");
            p.sendMessage(ChatColor.AQUA + "/alliance info <name|id>");
            p.sendMessage(ChatColor.AQUA + "/alliance role set <nation> <leader|officer|member> - Set a nation's alliance role (leader only to assign leader)");
            p.sendMessage(ChatColor.AQUA + "/alliance role list - List nations and roles in your alliance");
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "create":
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "Usage: /alliance create <name>");
                    return true;
                }
                if (!profile.hasNation()) {
                    p.sendMessage(ChatColor.RED + "You must be in a nation to create an alliance.");
                    return true;
                }
                Nation n = profile.getNation();
                if (!n.isLeader(uuid) && n.getRole(uuid) != Nation.Role.OFFICER) {
                    p.sendMessage(ChatColor.RED + "Only leaders or officers can create alliances.");
                    return true;
                }
                String name = args[1];
                Alliance a = AllianceManager.createAlliance(name, n);
                p.sendMessage(ChatColor.GREEN + "Alliance " + a.getName() + " created.");
                break;
            case "invite":
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "Usage: /alliance invite <nation>");
                    return true;
                }
                if (!profile.hasNation()) {
                    p.sendMessage(ChatColor.RED + "You must be in a nation to invite to an alliance.");
                    return true;
                }
                Nation inviterNation = profile.getNation();
                if (!inviterNation.isLeader(uuid) && inviterNation.getRole(uuid) != Nation.Role.OFFICER) {
                    p.sendMessage(ChatColor.RED + "Only leaders or officers can invite nations.");
                    return true;
                }
                String targetName = args[1];
                Nation target = NationManager.getNation(targetName);
                if (target == null) {
                    p.sendMessage(ChatColor.RED + "Target nation not found.");
                    return true;
                }
                Alliance invAlliance = AllianceManager.getAllianceForNation(inviterNation);
                if (invAlliance == null) {
                    p.sendMessage(ChatColor.RED + "Your nation is not in an alliance.");
                    return true;
                }
                AllianceManager.inviteNation(invAlliance, target);
                p.sendMessage(ChatColor.GREEN + "Invitation sent to " + target.getName());
                return true;
            case "accept":
                if (!profile.hasNation()) {
                    p.sendMessage(ChatColor.RED + "You must be in a nation to accept an alliance.");
                    return true;
                }
                Nation tNation = profile.getNation();
                if (!AllianceManager.hasInvite(tNation)) {
                    p.sendMessage(ChatColor.RED + "You have no pending alliance invites.");
                    return true;
                }
                AllianceManager.acceptInvite(tNation);
                p.sendMessage(ChatColor.GREEN + "Alliance joined.");
                return true;
            case "leave":
                if (!profile.hasNation()) {
                    p.sendMessage(ChatColor.RED + "You must be in a nation to leave an alliance.");
                    return true;
                }
                if (AllianceManager.leaveAlliance(profile.getNation())) {
                    p.sendMessage(ChatColor.GREEN + "Left alliance.");
                } else {
                    p.sendMessage(ChatColor.RED + "You are not in an alliance.");
                }
                return true;
            case "role":
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "Usage: /alliance role <set|list> ...");
                    return true;
                }
                String rop = args[1].toLowerCase();
                if (rop.equals("set")) {
                    if (args.length < 4) { p.sendMessage(ChatColor.RED + "Usage: /alliance role set <nation> <leader|officer|member>"); return true; }
                    if (!profile.hasNation()) { p.sendMessage(ChatColor.RED + "You must be in a nation to manage roles."); return true; }
                    Nation myNation = profile.getNation();
                    Alliance myAlliance = AllianceManager.getAllianceForNation(myNation);
                    if (myAlliance == null) { p.sendMessage(ChatColor.RED + "Your nation is not in an alliance."); return true; }
                    Alliance.Role myRole = myAlliance.getRole(myNation.getId());
                    if (myRole != Alliance.Role.LEADER && myRole != Alliance.Role.OFFICER) { p.sendMessage(ChatColor.RED + "Only leaders or officers can assign roles (leader only to assign leader)."); return true; }
                    Nation targetNation = NationManager.getNation(args[2]);
                    if (targetNation == null) { p.sendMessage(ChatColor.RED + "Target nation not found."); return true; }
                    if (targetNation.getAllianceId() == null || !targetNation.getAllianceId().equals(myAlliance.getId())) { p.sendMessage(ChatColor.RED + "Target nation is not in your alliance."); return true; }
                    String roleName = args[3].toUpperCase();
                    Alliance.Role newRole;
                    try { newRole = Alliance.Role.valueOf(roleName); } catch (Exception ex) { p.sendMessage(ChatColor.RED + "Unknown role."); return true; }
                    if (newRole == Alliance.Role.LEADER && myRole != Alliance.Role.LEADER) { p.sendMessage(ChatColor.RED + "Only the alliance leader can assign a leader."); return true; }
                    // if transferring leadership, demote current leader
                    if (newRole == Alliance.Role.LEADER) {
                        // find current leader
                        for (UUID nid : myAlliance.getMembers()) {
                            if (myAlliance.getRole(nid) == Alliance.Role.LEADER) {
                                myAlliance.setRole(nid, Alliance.Role.MEMBER);
                                break;
                            }
                        }
                    }
                    AllianceManager.setRole(myAlliance, targetNation.getId(), newRole);
                    p.sendMessage(ChatColor.GREEN + "Assigned role " + newRole.name() + " to " + targetNation.getName());
                    return true;
                } else if (rop.equals("list")) {
                    if (!profile.hasNation()) { p.sendMessage(ChatColor.RED + "You must be in a nation to view roles."); return true; }
                    Nation myN = profile.getNation();
                    Alliance myA = AllianceManager.getAllianceForNation(myN);
                    if (myA == null) { p.sendMessage(ChatColor.RED + "Your nation is not in an alliance."); return true; }
                    p.sendMessage(ChatColor.GOLD + "=== Alliance Roles: " + myA.getName() + " ===");
                    for (UUID nid : myA.getMembers()) {
                        Nation n2 = NationManager.getNationById(nid);
                        String nm = n2 != null ? n2.getName() : nid.toString();
                        p.sendMessage(ChatColor.AQUA + nm + ChatColor.GRAY + " - " + myA.getRole(nid).name());
                    }
                    return true;
                } else {
                    p.sendMessage(ChatColor.RED + "Unknown role operation.");
                    return true;
                }
            case "info":
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "Usage: /alliance info <name|id>");
                    return true;
                }
                String q = args[1];
                Alliance found = null;
                try {
                    UUID id = UUID.fromString(q);
                    found = AllianceManager.getAlliance(id);
                } catch (Exception ignored) {}
                if (found == null) {
                    for (Alliance a2 : AllianceManager.getAllAlliances()) {
                        if (a2.getName().equalsIgnoreCase(q)) {
                            found = a2; break;
                        }
                    }
                }
                if (found == null) {
                    p.sendMessage(ChatColor.RED + "Alliance not found.");
                    return true;
                }
                p.sendMessage(ChatColor.GOLD + "=== Alliance: " + found.getName() + " ===");
                p.sendMessage(ChatColor.AQUA + "Members: " + found.getMembers().size());
                return true;
            default:
                p.sendMessage(ChatColor.RED + "Unknown subcommand.");
                return true;
        }

        return true;
    }
}