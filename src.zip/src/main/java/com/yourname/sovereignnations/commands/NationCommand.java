package com.yourname.sovereignnations.commands;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.core.*;
import com.yourname.sovereignnations.claims.*;
import com.yourname.sovereignnations.hooks.DynmapHook;
import com.yourname.sovereignnations.gui.GUIManager;
import com.yourname.sovereignnations.visual.ClaimVisuals;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

public class NationCommand implements CommandExecutor, TabCompleter {

    private final SovereignNations plugin;

    public NationCommand(SovereignNations plugin) {
        this.plugin = plugin;
        plugin.getCommand("nation").setExecutor(this);
        plugin.getCommand("nation").setTabCompleter(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("Players only.");
            return true;
        }

        Player player = (Player) sender;
        PlayerProfile profile = PlayerProfileManager.getProfile(player);

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {

            case "create": return create(player, profile, args);
            case "join": return join(player, profile, args);
            case "leave": return leave(player, profile);
            case "info": return info(player, profile);
            case "gui": return gui(player, profile);

            case "spawn": return spawn(player, profile);
            case "setspawn": return setSpawn(player, profile);

            case "deposit": return deposit(player, profile, args);
            case "withdraw": return withdraw(player, profile, args);

            case "claim": return claim(player, profile);
            case "unclaim": return unclaim(player, profile);

            case "map": return map(player);
            case "list": return list(player);

            default:
                player.sendMessage(ChatColor.RED + "Unknown subcommand.");
                return true;
        }
    }

    private void sendHelp(Player p) {
        p.sendMessage(ChatColor.GOLD + "=== Nation Commands ===");
        p.sendMessage(ChatColor.AQUA + "/nation create <name>");
        p.sendMessage(ChatColor.AQUA + "/nation join <name>");
        p.sendMessage(ChatColor.AQUA + "/nation leave");
        p.sendMessage(ChatColor.AQUA + "/nation info");
        p.sendMessage(ChatColor.AQUA + "/nation spawn");
        p.sendMessage(ChatColor.AQUA + "/nation setspawn");
        p.sendMessage(ChatColor.AQUA + "/nation claim | unclaim");
        p.sendMessage(ChatColor.AQUA + "/nation gui");
    }

    private boolean create(Player p, PlayerProfile profile, String[] args) {
        if (args.length < 2) return true;
        if (profile.hasNation()) return true;
        if (NationManager.nationExists(args[1])) return true;

        Nation nation = NationManager.createNation(args[1], p.getUniqueId());
        profile.setNation(nation);
        profile.setRole(Nation.Role.LEADER);

        Bukkit.broadcastMessage(ChatColor.GOLD + "Nation formed: " + ChatColor.AQUA + nation.getName());
        return true;
    }

    private boolean join(Player p, PlayerProfile profile, String[] args) {
        if (args.length < 2 || profile.hasNation()) return true;

        Nation nation = NationManager.getNation(args[1]);
        if (nation == null) return true;

        nation.addMember(p.getUniqueId(), Nation.Role.MEMBER);

        profile.setNation(nation);
        profile.setRole(Nation.Role.MEMBER);
        NationManager.saveAll();

        p.sendMessage(ChatColor.GREEN + "Joined " + nation.getName());
        return true;
    }

    private boolean leave(Player p, PlayerProfile profile) {
        if (!profile.hasNation()) return true;

        Nation n = profile.getNation();
        if (n.isLeader(p.getUniqueId())) {
            p.sendMessage(ChatColor.RED + "Transfer leadership first.");
            return true;
        }

        n.removeMember(p.getUniqueId());
        profile.setNation(null);
        p.sendMessage(ChatColor.GREEN + "You left " + n.getName());
        return true;
    }

    private boolean info(Player p, PlayerProfile profile) {
        if (!profile.hasNation()) return true;

        Nation n = profile.getNation();
        p.sendMessage(ChatColor.GOLD + "=== " + n.getName() + " ===");
        p.sendMessage("Leader: " + n.getLeaderName());
        p.sendMessage("Members: " + n.getMemberCount());
        p.sendMessage("Balance: " + n.getBalance());
        return true;
    }

    private boolean gui(Player p, PlayerProfile profile) {
        if (!profile.hasNation()) return true;
        GUIManager.openNationGUI(p);
        return true;
    }

    private boolean setSpawn(Player p, PlayerProfile profile) {
        if (!profile.hasNation()) return true;

        Nation n = profile.getNation();
        if (!n.isLeader(p.getUniqueId())) return true;

        n.setSpawn(p.getLocation());
        NationManager.saveAll();
        p.sendMessage(ChatColor.GREEN + "Nation spawn set.");
        return true;
    }

    private boolean spawn(Player p, PlayerProfile profile) {
        if (!profile.hasNation()) return true;

        Location loc = profile.getNation().getSpawn();
        if (loc == null) return true;

        p.teleport(loc);
        return true;
    }

    private boolean deposit(Player p, PlayerProfile profile, String[] args) {
        if (!profile.hasNation() || args.length < 2) return true;

        Nation n = profile.getNation();
        double amt = Double.parseDouble(args[1]);

        if (!EconomyManager.withdrawPlayer(p, amt)) return true;

        n.deposit(amt);
        NationManager.saveAll();
        return true;
    }

    private boolean withdraw(Player p, PlayerProfile profile, String[] args) {
        if (!profile.hasNation() || args.length < 2) return true;

        Nation n = profile.getNation();
        if (!n.isLeader(p.getUniqueId())) return true;

        double amt = Double.parseDouble(args[1]);
        if (!n.withdraw(amt)) return true;

        EconomyManager.depositPlayer(p, amt);
        NationManager.saveAll();
        return true;
    }

    private boolean claim(Player p, PlayerProfile profile) {
        if (!profile.hasNation()) return true;

        Chunk chunk = p.getLocation().getChunk();
        if (!ClaimManager.addClaim(profile.getNation(), chunk)) return true;

        Claim c = ClaimManager.getClaim(chunk);
        if (c != null) DynmapHook.addClaimMarker(c);

        ClaimVisuals.showChunkBorderToPlayer(p, chunk, 5);
        return true;
    }

    private boolean unclaim(Player p, PlayerProfile profile) {
        if (!profile.hasNation()) return true;

        Chunk chunk = p.getLocation().getChunk();
        Claim c = ClaimManager.getClaim(chunk);

        if (c == null || !c.getNation().equals(profile.getNation())) return true;

        ClaimManager.removeClaim(profile.getNation(), chunk);
        DynmapHook.removeClaimMarker(c);
        return true;
    }

    private boolean list(Player p) {
        p.sendMessage(ChatColor.GOLD + "=== Nations ===");
        for (Nation n : NationManager.getAllNations()) {
            p.sendMessage(ChatColor.AQUA + n.getName() + ChatColor.GRAY + " (" + n.getMemberCount() + ")");
        }
        return true;
    }

    private boolean map(Player p) {
        for (String line : MapRenderer.renderMap(p, 27, 7)) {
            p.sendMessage(line);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList(
                    "create","join","leave","info","spawn","setspawn",
                    "claim","unclaim","gui","map","list","deposit","withdraw"
            );
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("join")) {
            List<String> list = new ArrayList<>();
            for (Nation n : NationManager.getAllNations()) list.add(n.getName());
            return list;
        }
        return Collections.emptyList();
    }
}
