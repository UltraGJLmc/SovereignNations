package com.yourname.sovereignnations.listeners;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.claims.Claim;
import com.yourname.sovereignnations.claims.ClaimManager;
import com.yourname.sovereignnations.core.EconomyManager;
import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.PlayerProfile;
import com.yourname.sovereignnations.core.PlayerProfileManager;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sends action-bar HUD showing claim info when a player enters a chunk.
 */
public class ClaimListener implements Listener {

    private final Map<UUID, Chunk> lastChunkByPlayer = new ConcurrentHashMap<>();

    @EventHandler(ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        if (event.getFrom().getChunk().equals(event.getTo().getChunk())) return;

        Player player = event.getPlayer();
        Chunk newChunk = player.getLocation().getChunk();

        lastChunkByPlayer.put(player.getUniqueId(), newChunk);

        Claim claim = ClaimManager.getClaim(newChunk);
        String message;

        if (claim != null) {
            Nation nation = claim.getNation();
            String name = claim.getName();
            message = ChatColor.GOLD + "Claimed: " +
                    ChatColor.YELLOW + (nation != null ? nation.getName() : "Unknown") +
                    (name != null ? ChatColor.GRAY + " (" + name + ")" : "");
        } else if (ClaimManager.isForSale(newChunk)) {
            message = ChatColor.YELLOW + "For Sale " +
                    ChatColor.GRAY + "(only members of nations can claim)";
        } else {
            message = ChatColor.GRAY + "Unclaimed";
        }

        player.spigot().sendMessage(
                ChatMessageType.ACTION_BAR,
                new TextComponent(message)
        );

        handleAutoclaim(player, newChunk);
    }

    /* ===================== */
    /* AUTOCLAIM */
    /* ===================== */

    private void handleAutoclaim(Player player, Chunk chunk) {
        try {
            PlayerProfile profile = PlayerProfileManager.getProfile(player);
            if (profile == null || !profile.hasNation()) return;

            Object ac = profile.getGuiSetting("autoclaim");
            if (!(ac instanceof Boolean) || !((Boolean) ac)) return;

            Nation nation = profile.getNation();
            if (nation == null) return;

            long now = System.currentTimeMillis();
            long last = getLastAutoclaim(profile);

            long cooldown = nation.getAutoclaimCooldownSeconds() >= 0
                    ? nation.getAutoclaimCooldownSeconds() * 1000L
                    : getGlobalAutoclaimCooldownMs();

            if (now - last < cooldown) return;
            profile.setGuiSetting("lastAutoclaim", now);

            if (ClaimManager.isClaimed(chunk) && !ClaimManager.isForSale(chunk)) return;

            boolean bought = ClaimManager.buyClaim(nation, chunk);
            if (bought) {
                player.sendMessage(
                        ChatColor.GREEN + "Auto-claimed this chunk for nation " +
                                nation.getName() + " for $" +
                                String.format("%.2f", ClaimManager.getClaimCost())
                );
            } else {
                double cost = ClaimManager.getClaimCost();
                if (!EconomyManager.hasEnoughNation(nation, cost)) {
                    player.sendMessage(
                            ChatColor.RED + "Nation does not have enough funds to auto-claim " +
                                    "(cost: $" + String.format("%.2f", cost) + ")"
                    );
                }
            }
        } catch (Exception ignored) {
            // Intentionally silent: autoclaim should NEVER crash movement
        }
    }

    private long getLastAutoclaim(PlayerProfile profile) {
        Object obj = profile.getGuiSetting("lastAutoclaim");
        if (obj instanceof Number) {
            return ((Number) obj).longValue();
        }
        return 0L;
    }

    private long getGlobalAutoclaimCooldownMs() {
        try {
            SovereignNations plugin = SovereignNations.get();
            if (plugin != null && plugin.getConfig() != null) {
                long seconds = plugin.getConfig()
                        .getLong("settings.autoclaim.cooldown-seconds", 5L);
                return Math.max(0L, seconds) * 1000L;
            }
        } catch (Exception ignored) {}
        return 5000L;
    }
}
