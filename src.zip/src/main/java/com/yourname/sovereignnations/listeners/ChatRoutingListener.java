package com.yourname.sovereignnations.listeners;

import com.yourname.sovereignnations.chat.ChatChannel;
import com.yourname.sovereignnations.chat.ChatManager;
import com.yourname.sovereignnations.core.AllianceManager;
import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.NationManager;
import com.yourname.sovereignnations.core.PlayerProfile;
import com.yourname.sovereignnations.core.PlayerProfileManager;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.entity.Player;

public class ChatRoutingListener implements Listener {

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player p = event.getPlayer();
        PlayerProfile profile = PlayerProfileManager.getProfile(p);
        ChatChannel channel = profile.getChatChannel();
        String message = event.getMessage();

        if (channel == ChatChannel.PUBLIC) {
            // Let it go through as normal, maybe prefix with [Public]
            event.setFormat(ChatColor.GRAY + "[Public] " + ChatColor.YELLOW + "%1$s" + ChatColor.WHITE + ": %2$s");
            return;
        }

        event.setCancelled(true);

        if (channel == ChatChannel.NATION) {
            if (!profile.hasNation()) {
                p.sendMessage(ChatColor.RED + "You are not in a nation. Use /nation chat public to switch.");
                profile.setChatChannel(ChatChannel.PUBLIC);
                return;
            }
            Nation n = profile.getNation();
            ChatManager.sendNationMessage(n, p, message);
            return;
        }

        if (channel == ChatChannel.ALLIANCE) {
            if (!profile.hasNation()) {
                p.sendMessage(ChatColor.RED + "You are not in a nation. Use /nation chat public to switch.");
                profile.setChatChannel(ChatChannel.PUBLIC);
                return;
            }
            Nation n = profile.getNation();
            if (n.getAllianceId() == null) {
                p.sendMessage(ChatColor.RED + "Your nation is not in an alliance.");
                profile.setChatChannel(ChatChannel.PUBLIC);
                return;
            }
            com.yourname.sovereignnations.core.Alliance a = AllianceManager.getAlliance(n.getAllianceId());
            if (a == null) {
                p.sendMessage(ChatColor.RED + "Your alliance could not be found.");
                profile.setChatChannel(ChatChannel.PUBLIC);
                return;
            }
            ChatManager.sendAllianceMessage(a, p, message);
        }
    }
}