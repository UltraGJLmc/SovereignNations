package com.yourname.sovereignnations.listeners;

import com.yourname.sovereignnations.gui.GUIManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

/**
 * Routes GUI events to GUIManager and prevents item movement.
 */
public class GUIListener implements Listener {

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        // Only handle plugin GUIs
        if (!GUIManager.isOpen(player)) return;

        // Let GUIManager handle everything (it cancels internally)
        GUIManager.handleClick(event);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;

        // Clean up tracking when GUI closes
        if (GUIManager.isOpen(player)) {
            GUIManager.close(player);
        }
    }
}
