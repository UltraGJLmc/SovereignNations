package com.yourname.sovereignnations.listeners;

import com.yourname.sovereignnations.claims.Claim;
import com.yourname.sovereignnations.claims.ClaimManager;
import com.yourname.sovereignnations.core.JailManager;
import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.NationManager;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.Arrays;
import java.util.UUID;

public class EnforcementListener implements Listener {

    private static final String[] TELEPORT_COMMANDS = new String[]{"/tp", "/tpa", "/tpahere", "/warp", "/home", "/spawn", "/back", "/teleport"};

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player p = event.getPlayer();
        Claim claim = ClaimManager.getClaim(p.getLocation().getChunk());
        if (claim == null) return;
        Nation n = claim.getNation();
        if (n == null) return;
        if (n.isOutlaw(p.getUniqueId())) {
            p.sendMessage(ChatColor.RED + "You are an outlaw here and cannot break blocks.");
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        if (!(event.getDamager() instanceof Player)) return;
        Player target = (Player) event.getEntity();
        Player damager = (Player) event.getDamager();

        Claim claim = ClaimManager.getClaim(target.getLocation().getChunk());
        if (claim == null) return;
        Nation n = claim.getNation();
        if (n == null) return;

        UUID tid = target.getUniqueId();
        UUID did = damager.getUniqueId();

        // If target is outlaw in this nation and damager is a nation member, ensure damage is allowed
        if (n.isOutlaw(tid) && n.getMembers().containsKey(did)) {
            // Allow damage even if other handlers attempted to cancel it
            event.setCancelled(false);
        }
    }

    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        Player p = event.getPlayer();
        // If player is jailed -> cancel teleport
        if (JailManager.isJailed(p.getUniqueId())) {
            p.sendMessage(ChatColor.RED + "You are jailed and cannot teleport.");
            event.setCancelled(true);
            return;
        }

        // If player is outlaw in the nation where they currently stand, prevent them teleporting away
        Claim claim = ClaimManager.getClaim(event.getFrom().getChunk());
        if (claim != null) {
            Nation n = claim.getNation();
            if (n != null && n.isOutlaw(p.getUniqueId())) {
                p.sendMessage(ChatColor.RED + "Outlaws cannot teleport while in nation territory.");
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        Player p = event.getPlayer();
        String msg = event.getMessage().toLowerCase();
        // Jail cannot use teleport commands
        if (JailManager.isJailed(p.getUniqueId())) {
            for (String c : TELEPORT_COMMANDS) {
                if (msg.startsWith(c)) {
                    p.sendMessage(ChatColor.RED + "You are jailed and cannot use teleport commands.");
                    event.setCancelled(true);
                    return;
                }
            }
        }

        // If player is outlaw in current nation's territory, block teleport-related commands
        Claim claim = ClaimManager.getClaim(p.getLocation().getChunk());
        if (claim != null) {
            Nation n = claim.getNation();
            if (n != null && n.isOutlaw(p.getUniqueId())) {
                for (String c : TELEPORT_COMMANDS) {
                    if (msg.startsWith(c)) {
                        p.sendMessage(ChatColor.RED + "Outlaws cannot use teleport commands while in nation territory.");
                        event.setCancelled(true);
                        return;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        if (JailManager.isJailed(p.getUniqueId())) {
            // Teleport to first available jail cell
            for (String cell : JailManager.getCellNames()) {
                Location loc = JailManager.getCell(cell);
                if (loc != null && loc.getWorld() != null) {
                    p.teleport(loc);
                    p.sendMessage(ChatColor.RED + "You are jailed until " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new java.util.Date(JailManager.getJailedUntil(p.getUniqueId()))));
                    break;
                }
            }
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player p = event.getPlayer();
        if (JailManager.isJailed(p.getUniqueId())) {
            // Keep them in the first jail cell
            for (String cell : JailManager.getCellNames()) {
                Location loc = JailManager.getCell(cell);
                if (loc != null && loc.getWorld() != null) {
                    double dx = p.getLocation().distance(loc);
                    if (dx > 3.0) p.teleport(loc);
                    return;
                }
            }
        }
    }
}
