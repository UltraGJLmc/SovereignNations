package com.yourname.sovereignnations.listeners;

import com.yourname.sovereignnations.gui.GUIManager;
import com.yourname.sovereignnations.claims.Claim;
import com.yourname.sovereignnations.claims.ClaimManager;
import com.yourname.sovereignnations.visual.ClaimVisuals;
import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.NationManager;
import com.yourname.sovereignnations.core.PlayerProfileManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.entity.Player;

import java.util.UUID;

public class ChatInputListener implements Listener {

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        boolean wasRename = GUIManager.pendingRename.containsKey(id);
        boolean wasCooldown = GUIManager.pendingCooldown.containsKey(id);
        boolean wasConfirm = GUIManager.pendingConfirmActions.containsKey(id);
        if (!wasRename && !wasCooldown && !wasConfirm) return;

        // consume input
        event.setCancelled(true);
        String msg = event.getMessage();

        if (wasRename) {
            GUIManager.pendingRename.remove(id);

            if (msg.equalsIgnoreCase("cancel")) {
                player.sendMessage("§cRename cancelled.");
                return;
            }

            org.bukkit.Chunk chunk = player.getLocation().getChunk();
            Claim claim = ClaimManager.getClaim(chunk);
            Nation n = PlayerProfileManager.getProfile(player).getNation();
            if (claim == null || n == null || !claim.getNationId().equals(n.getId())) {
                player.sendMessage("§cYou can only rename chunks that belong to your nation.");
                return;
            }

            if (!n.isLeader(player.getUniqueId()) && !player.hasPermission("sovereignnations.admin")) {
                player.sendMessage("§cOnly the nation leader can rename chunks.");
                return;
            }

            claim.setName(msg);
            ClaimManager.saveAll();
            player.sendMessage("§aChunk renamed to: §e" + msg);
            com.yourname.sovereignnations.gui.GUIManager.sendTitle(player, "Chunk Renamed", msg);
            // Show visuals on main thread
            player.getServer().getScheduler().runTask(com.yourname.sovereignnations.SovereignNations.get(), () -> {
                ClaimVisuals.showChunkBorderToPlayer(player, chunk, 3);
            });
            return;
        }

        // Handle custom autoclaim cooldown input
        if (wasCooldown) {
            String nationName = GUIManager.pendingCooldown.get(id);
            GUIManager.pendingCooldown.remove(id);
            if (msg.equalsIgnoreCase("cancel")) {
                player.sendMessage("§cAutoclaim change cancelled.");
                return;
            }
            Nation target = NationManager.getNation(nationName);
            if (target == null) { player.sendMessage("§cNation not found."); return; }
            try {
                long secs = Long.parseLong(msg);
                if (secs < 0) {
                    // -1 disable
                    if (secs == -1) target.setAutoclaimCooldownSeconds(-2L);
                    else { player.sendMessage("§cSeconds must be -1 (disable) or >= 0."); return; }
                } else {
                    target.setAutoclaimCooldownSeconds(secs == 0 ? -1L : secs);
                }
                NationManager.saveAll();
                player.sendMessage("§aAutoclaim cooldown updated for " + target.getName());
            } catch (NumberFormatException ex) {
                player.sendMessage("§cInvalid number. Please enter seconds (integer).");
            }
            return;
        }

        // Handle typed confirmations
        if (wasConfirm) {
            if (msg.equalsIgnoreCase("cancel")) {
                GUIManager.pendingConfirmActions.remove(id);
                GUIManager.pendingConfirmMessages.remove(id);
                player.sendMessage("§cAction cancelled.");
                return;
            }
            if (msg.equalsIgnoreCase("confirm")) {
                java.lang.Runnable action = GUIManager.pendingConfirmActions.remove(id);
                GUIManager.pendingConfirmMessages.remove(id);
                if (action != null) {
                    com.yourname.sovereignnations.SovereignNations.get().getServer().getScheduler().runTask(com.yourname.sovereignnations.SovereignNations.get(), action);
                    player.sendMessage("§aConfirmed.");
                } else {
                    player.sendMessage("§cNo action to confirm.");
                }
            } else {
                player.sendMessage("§eType 'confirm' to proceed or 'cancel' to abort.");
            }
            return;
        }
    }
}