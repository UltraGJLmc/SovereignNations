package com.yourname.sovereignnations.util;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.util.UUID;

public class PlayerUtil {
    public static UUID getUUIDForName(String name) {
        OfflinePlayer op = Bukkit.getOfflinePlayer(name);
        if (op == null) return null;
        UUID id = op.getUniqueId();
        return id;
    }
}