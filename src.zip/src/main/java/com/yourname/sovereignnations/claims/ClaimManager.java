package com.yourname.sovereignnations.claims;

import com.yourname.sovereignnations.SovereignNations;
import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.EconomyManager;
import com.yourname.sovereignnations.core.Tier;
import com.yourname.sovereignnations.core.TierManager;
import org.bukkit.Chunk;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages all nation claims.
 */
public final class ClaimManager {

    private static SovereignNations plugin;
    private static File claimsFile;
    private static FileConfiguration claimsConfig;

    // world -> (x,z -> claim)
    private static final Map<String, Map<String, Claim>> claims = new ConcurrentHashMap<>();

    // "world:x,z" -> true
    private static final Map<String, Boolean> forSale = new ConcurrentHashMap<>();

    private static double claimCost = 5.0;

    /* ===================== */
    /* INIT */
    /* ===================== */

    public static void init(SovereignNations pluginInstance) {
        plugin = pluginInstance;

        claimsFile = new File(plugin.getDataFolder(), "claims.yml");
        if (!claimsFile.exists()) {
            plugin.saveResource("claims.yml", false);
        }

        claimCost = plugin.getConfig().getDouble("settings.claims.cost",
                plugin.getConfig().getDouble("claims.cost", 5.0));

        claimsConfig = YamlConfiguration.loadConfiguration(claimsFile);

        loadAll();
    }

    /* ===================== */
    /* LOAD */
    /* ===================== */

    public static void loadAll() {
        claims.clear();
        forSale.clear();

        ConfigurationSection root = claimsConfig.getConfigurationSection("claims");
        if (root == null) return;

        for (String worldName : root.getKeys(false)) {
            ConfigurationSection worldSec = root.getConfigurationSection(worldName);
            if (worldSec == null) continue;

            Map<String, Claim> worldClaims = new ConcurrentHashMap<>();

            for (String chunkKey : worldSec.getKeys(false)) {
                ConfigurationSection cs = worldSec.getConfigurationSection(chunkKey);
                if (cs == null) continue;

                try {
                    UUID nationId = UUID.fromString(cs.getString("nation"));
                    long claimedAt = cs.getLong("claimedAt", System.currentTimeMillis());

                    String[] parts = chunkKey.split(",");
                    int x = Integer.parseInt(parts[0]);
                    int z = Integer.parseInt(parts[1]);

                    Claim claim = new Claim(nationId, worldName, x, z, claimedAt);
                    claim.setPvpAllowed(cs.getBoolean("pvp", false));

                    if (cs.contains("name")) claim.setName(cs.getString("name"));
                    if (cs.contains("type")) {
                        try {
                            claim.setPlotType(Claim.PlotType.valueOf(cs.getString("type")));
                        } catch (Exception ignored) {}
                    }

                    worldClaims.put(chunkKey, claim);

                    Nation nation = claim.getNation();
                    if (nation != null) {
                        nation.addClaim(worldName, chunkKey);
                    }

                } catch (Exception ex) {
                    plugin.getLogger().warning("Failed to load claim " + worldName + ":" + chunkKey);
                }
            }

            claims.put(worldName, worldClaims);
        }

        ConfigurationSection saleSec = claimsConfig.getConfigurationSection("forsale");
        if (saleSec != null) {
            for (String key : saleSec.getKeys(false)) {
                forSale.put(key, true);
            }
        }
    }

    /* ===================== */
    /* SAVE */
    /* ===================== */

    public static synchronized void saveAll() {
        claimsConfig.set("claims", null);
        claimsConfig.set("forsale", null);

        ConfigurationSection root = claimsConfig.createSection("claims");

        for (Map.Entry<String, Map<String, Claim>> worldEntry : claims.entrySet()) {
            ConfigurationSection worldSec = root.createSection(worldEntry.getKey());

            for (Map.Entry<String, Claim> entry : worldEntry.getValue().entrySet()) {
                Claim claim = entry.getValue();
                ConfigurationSection cs = worldSec.createSection(entry.getKey());

                cs.set("nation", claim.getNationId().toString());
                cs.set("pvp", claim.isPvpAllowed());
                cs.set("claimedAt", claim.getClaimedAt());

                if (claim.getName() != null) cs.set("name", claim.getName());
                if (claim.getPlotType() != null && claim.getPlotType() != Claim.PlotType.NONE) {
                    cs.set("type", claim.getPlotType().name());
                }
            }
        }

        ConfigurationSection saleSec = claimsConfig.createSection("forsale");
        for (String key : forSale.keySet()) {
            saleSec.set(key, true);
        }

        try {
            claimsConfig.save(claimsFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* ===================== */
    /* QUERY */
    /* ===================== */

    public static Claim getClaim(Chunk chunk) {
        Map<String, Claim> worldClaims = claims.get(chunk.getWorld().getName());
        if (worldClaims == null) return null;
        return worldClaims.get(chunk.getX() + "," + chunk.getZ());
    }

    public static boolean isClaimed(Chunk chunk) {
        return getClaim(chunk) != null;
    }

    public static boolean isClaimedByNation(Chunk chunk, Nation nation) {
        Claim claim = getClaim(chunk);
        return claim != null && nation != null && claim.getNationId().equals(nation.getId());
    }

    /* ===================== */
    /* CLAIM ACTIONS */
    /* ===================== */

    public static boolean canClaim(Nation nation) {
        if (nation == null) return false;
        Tier tier = TierManager.getTier(nation.getTier());
        int max = tier != null ? tier.getMaxClaims() : Integer.MAX_VALUE;
        return getAllClaims(nation).size() < max;
    }

    public static boolean addClaim(Nation nation, Chunk chunk) {
        if (nation == null || isClaimed(chunk) || !canClaim(nation)) return false;

        String world = chunk.getWorld().getName();
        String key = chunk.getX() + "," + chunk.getZ();

        Claim claim = new Claim(nation, chunk);
        claims.computeIfAbsent(world, w -> new ConcurrentHashMap<>()).put(key, claim);
        nation.addClaim(world, key);

        return true;
    }

    public static boolean buyClaim(Nation nation, Chunk chunk) {
        if (nation == null || isClaimed(chunk) || !canClaim(nation)) return false;

        if (!EconomyManager.withdrawNation(nation, claimCost)) return false;

        if (!addClaim(nation, chunk)) {
            EconomyManager.depositNation(nation, claimCost);
            return false;
        }

        saveAll();
        return true;
    }

    public static boolean removeClaim(Nation nation, Chunk chunk) {
        Claim claim = getClaim(chunk);
        if (claim == null || nation == null || !claim.getNationId().equals(nation.getId())) return false;

        Map<String, Claim> worldClaims = claims.get(chunk.getWorld().getName());
        if (worldClaims != null) {
            worldClaims.remove(chunk.getX() + "," + chunk.getZ());
        }

        nation.removeClaim(chunk.getWorld().getName(), chunk.getX() + "," + chunk.getZ());
        return true;
    }

    /* ===================== */
    /* FILL */
    /* ===================== */

    public static int fillClaims(Nation nation, Chunk center, int radius) {
        if (nation == null || radius < 0) return 0;

        int count = 0;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                Chunk c = center.getWorld().getChunkAt(center.getX() + dx, center.getZ() + dz);
                if (!isClaimed(c)) {
                    if (buyClaim(nation, c)) count++;
                    else return count;
                }
            }
        }
        return count;
    }

    /* ===================== */
    /* FOR SALE */
    /* ===================== */

    private static String keyFor(Chunk chunk) {
        return chunk.getWorld().getName() + ":" + chunk.getX() + "," + chunk.getZ();
    }

    public static boolean isForSale(Chunk chunk) {
        return forSale.getOrDefault(keyFor(chunk), false);
    }

    public static boolean setForSale(Chunk chunk, boolean on) {
        String key = keyFor(chunk);
        if (on) forSale.put(key, true);
        else forSale.remove(key);
        saveAll();
        return on;
    }

    public static boolean toggleForSale(Chunk chunk) {
        return setForSale(chunk, !isForSale(chunk));
    }

    /* ===================== */
    /* MISC */
    /* ===================== */

    public static List<Claim> getAllClaims(Nation nation) {
        List<Claim> list = new ArrayList<>();
        for (Map<String, Claim> world : claims.values()) {
            for (Claim claim : world.values()) {
                if (claim.getNationId().equals(nation.getId())) list.add(claim);
            }
        }
        return list;
    }

    public static List<Claim> getAllClaims() {
        List<Claim> list = new ArrayList<>();
        for (Map<String, Claim> world : claims.values()) {
            list.addAll(world.values());
        }
        return list;
    }

    public static double getClaimCost() {
        return claimCost;
    }

    public static boolean unclaimChunk(Claim claim) {
        if (claim == null) return false;

        Map<String, Claim> worldClaims = claims.get(claim.getWorldName());
        if (worldClaims == null) return false;

        String key = claim.getChunkX() + "," + claim.getChunkZ();
        worldClaims.remove(key);

        Nation nation = claim.getNation();
        if (nation != null) {
            nation.removeClaim(claim.getWorldName(), key);
        }
        return true;
    }
}
