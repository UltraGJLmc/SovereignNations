package com.yourname.sovereignnations.claims;

import com.yourname.sovereignnations.core.Nation;
import com.yourname.sovereignnations.core.NationManager;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.UUID;
/**
 * Represents a single claimed chunk by a Nation.
 */
public class Claim {

    private final UUID nationId;
    private final String worldName;
    private final int chunkX;
    private final int chunkZ;

    // Optional metadata
    private boolean pvpAllowed = false; // per-claim PVP override
    private long claimedAt;

    // Optional user-facing name for the claim
    private String name;

    // Plot type (arena, bank, embassy, farm, inn, jail, shop, etc.)
    private PlotType plotType = PlotType.NONE;

    public enum PlotType {
        NONE,
        ARENA,
        BANK,
        EMBASSY,
        FARM,
        INN,
        JAIL,
        SHOP
    }

    /* ===================== */
    /* CONSTRUCTOR */
    /* ===================== */
    public Claim(Nation nation, Chunk chunk) {
        this.nationId = nation.getId();
        this.worldName = chunk.getWorld().getName();
        this.chunkX = chunk.getX();
        this.chunkZ = chunk.getZ();
        this.claimedAt = System.currentTimeMillis();
    }

    public Claim(UUID nationId, String worldName, int chunkX, int chunkZ, long claimedAt) {
        this.nationId = nationId;
        this.worldName = worldName;
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
        this.claimedAt = claimedAt;
    }

    /* ===================== */
    /* GETTERS & SETTERS */
    /* ===================== */
    public UUID getNationId() {
        return nationId;
    }

    public Nation getNation() {
        return NationManager.getAllNations().stream()
                .filter(n -> n.getId().equals(nationId))
                .findFirst()
                .orElse(null);
    }

    public String getWorldName() {
        return worldName;
    }

    public World getWorld() {
        return Bukkit.getWorld(worldName);
    }

    public int getChunkX() {
        return chunkX;
    }

    public int getChunkZ() {
        return chunkZ;
    }

    public boolean isPvpAllowed() {
        return pvpAllowed;
    }

    public void setPvpAllowed(boolean pvpAllowed) {
        this.pvpAllowed = pvpAllowed;
    }

    public long getClaimedAt() {
        return claimedAt;
    }

    public void setClaimedAt(long claimedAt) {
        this.claimedAt = claimedAt;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PlotType getPlotType() {
        return plotType;
    }

    public void setPlotType(PlotType plotType) {
        this.plotType = plotType;
    }

    /* ===================== */
    /* UTILITIES */
    /* ===================== */

    /**
     * Returns a string key for storing in claims.yml, like "world:chunkX,chunkZ"
     */
    public String getKey() {
        return chunkX + "," + chunkZ;
    }

    /**
     * Checks if a given chunk matches this claim
     */
    public boolean matchesChunk(Chunk chunk) {
        return chunk.getWorld().getName().equals(worldName)
                && chunk.getX() == chunkX
                && chunk.getZ() == chunkZ;
    }

    /**
     * Returns a human-readable string of the claim
     */
    @Override
    public String toString() {
        Nation nation = getNation();
        String nationName = (nation != null) ? nation.getName() : "Unknown";
        String label = (name != null && !name.isEmpty()) ? (" - " + name) : "";
        return "[" + nationName + "] " + worldName + " (" + chunkX + "," + chunkZ + ")" + label;
    }
}
